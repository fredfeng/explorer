package antlr;

public class Version {
    public static final String version = "2";
    public static final String subversion = "7";
    public static final String patchlevel = "2";
    public static final String datestamp = "20030117";
    public static final String project_version = "2.7.2";
}
