package antlr.debug;

public class ParserTokenAdapter implements ParserTokenListener {


	public void doneParsing(TraceEvent e) {}
	public void parserConsume(ParserTokenEvent e) {}
	public void parserLA(ParserTokenEvent e) {}
	public void refresh() {}
}