/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Elements, a Sable suite of simple Java programs                   *
 * Copyright (C) 1998 Raja Vallee-Rai (kor@sable.mcgill.ca)          *
 * All rights reserved.                                              *
 *                                                                   *
 * This work was done as a project of the Sable Research Group,      *
 * School of Computer Science, McGill University, Canada             *
 * (http://www.sable.mcgill.ca/).  It is understood that any         *
 * modification not identified as such is not covered by the         *
 * preceding statement.                                              *
 *                                                                   *
 * This work is free software; you can redistribute it and/or        *
 * modify it under the terms of the GNU Library General Public       *
 * License as published by the Free Software Foundation; either      *
 * version 2 of the License, or (at your option) any later version.  *
 *                                                                   *
 * This work is distributed in the hope that it will be useful,      *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU *
 * Library General Public License for more details.                  *
 *                                                                   *
 * You should have received a copy of the GNU Library General Public *
 * License along with this library; if not, write to the             *
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,      *
 * Boston, MA  02111-1307, USA.                                      *
 *                                                                   *
 * Java is a trademark of Sun Microsystems, Inc.                     *
 *                                                                   *
 * To submit a bug report, send a comment, or get the latest news on *
 * this project and other Sable Research Group projects, please      *
 * visit the web site: http://www.sable.mcgill.ca/                   *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/*
 Reference Version
 -----------------
 This is the latest official version on which this file is based.
 The reference version is: $?$

 Change History
 --------------
 A) Notes:

 Please use the following template.  Most recent changes should
 appear at the top of the list.

 - Modified on [date (March 1, 1900)] by [name]. [(*) if appropriate]
   [description of modification].

 Any Modification flagged with "(*)" was done as a project of the
 Sable Research Group, School of Computer Science,
 McGill University, Canada (http://www.sable.mcgill.ca/).

 You should add your copyright, using the following template, at
 the top of this file, along with other copyrights.

 *                                                                   *
 * Modifications by [name] are                                       *
 * Copyright (C) [year(s)] [your name (or company)].  All rights     *
 * reserved.                                                         *
 *                                                                   *

 B) Changes:

 - Modified on September 12, 1998 by Raja Vallee-Rai (kor@sable.mcgill.ca) (*)
   First internal release.
*/


class Main
{
    public static void main(String[] argv)
    {
System.out.println("i0");
System.out.println("i1");
System.out.println("i2");
System.out.println("i3");
System.out.println("i4");
System.out.println("i5");
System.out.println("i6");
System.out.println("i7");
System.out.println("i8");
System.out.println("i9");
System.out.println("i10");
System.out.println("i11");
System.out.println("i12");
System.out.println("i13");
System.out.println("i14");
System.out.println("i15");
System.out.println("i16");
System.out.println("i17");
System.out.println("i18");
System.out.println("i19");
System.out.println("i20");
System.out.println("i21");
System.out.println("i22");
System.out.println("i23");
System.out.println("i24");
System.out.println("i25");
System.out.println("i26");
System.out.println("i27");
System.out.println("i28");
System.out.println("i29");
System.out.println("i30");
System.out.println("i31");
System.out.println("i32");
System.out.println("i33");
System.out.println("i34");
System.out.println("i35");
System.out.println("i36");
System.out.println("i37");
System.out.println("i38");
System.out.println("i39");
System.out.println("i40");
System.out.println("i41");
System.out.println("i42");
System.out.println("i43");
System.out.println("i44");
System.out.println("i45");
System.out.println("i46");
System.out.println("i47");
System.out.println("i48");
System.out.println("i49");
System.out.println("i50");
System.out.println("i51");
System.out.println("i52");
System.out.println("i53");
System.out.println("i54");
System.out.println("i55");
System.out.println("i56");
System.out.println("i57");
System.out.println("i58");
System.out.println("i59");
System.out.println("i60");
System.out.println("i61");
System.out.println("i62");
System.out.println("i63");
System.out.println("i64");
System.out.println("i65");
System.out.println("i66");
System.out.println("i67");
System.out.println("i68");
System.out.println("i69");
System.out.println("i70");
System.out.println("i71");
System.out.println("i72");
System.out.println("i73");
System.out.println("i74");
System.out.println("i75");
System.out.println("i76");
System.out.println("i77");
System.out.println("i78");
System.out.println("i79");
System.out.println("i80");
System.out.println("i81");
System.out.println("i82");
System.out.println("i83");
System.out.println("i84");
System.out.println("i85");
System.out.println("i86");
System.out.println("i87");
System.out.println("i88");
System.out.println("i89");
System.out.println("i90");
System.out.println("i91");
System.out.println("i92");
System.out.println("i93");
System.out.println("i94");
System.out.println("i95");
System.out.println("i96");
System.out.println("i97");
System.out.println("i98");
System.out.println("i99");
System.out.println("i100");
System.out.println("i101");
System.out.println("i102");
System.out.println("i103");
System.out.println("i104");
System.out.println("i105");
System.out.println("i106");
System.out.println("i107");
System.out.println("i108");
System.out.println("i109");
System.out.println("i110");
System.out.println("i111");
System.out.println("i112");
System.out.println("i113");
System.out.println("i114");
System.out.println("i115");
System.out.println("i116");
System.out.println("i117");
System.out.println("i118");
System.out.println("i119");
System.out.println("i120");
System.out.println("i121");
System.out.println("i122");
System.out.println("i123");
System.out.println("i124");
System.out.println("i125");
System.out.println("i126");
System.out.println("i127");
System.out.println("i128");
System.out.println("i129");
System.out.println("i130");
System.out.println("i131");
System.out.println("i132");
System.out.println("i133");
System.out.println("i134");
System.out.println("i135");
System.out.println("i136");
System.out.println("i137");
System.out.println("i138");
System.out.println("i139");
System.out.println("i140");
System.out.println("i141");
System.out.println("i142");
System.out.println("i143");
System.out.println("i144");
System.out.println("i145");
System.out.println("i146");
System.out.println("i147");
System.out.println("i148");
System.out.println("i149");
System.out.println("i150");
System.out.println("i151");
System.out.println("i152");
System.out.println("i153");
System.out.println("i154");
System.out.println("i155");
System.out.println("i156");
System.out.println("i157");
System.out.println("i158");
System.out.println("i159");
System.out.println("i160");
System.out.println("i161");
System.out.println("i162");
System.out.println("i163");
System.out.println("i164");
System.out.println("i165");
System.out.println("i166");
System.out.println("i167");
System.out.println("i168");
System.out.println("i169");
System.out.println("i170");
System.out.println("i171");
System.out.println("i172");
System.out.println("i173");
System.out.println("i174");
System.out.println("i175");
System.out.println("i176");
System.out.println("i177");
System.out.println("i178");
System.out.println("i179");
System.out.println("i180");
System.out.println("i181");
System.out.println("i182");
System.out.println("i183");
System.out.println("i184");
System.out.println("i185");
System.out.println("i186");
System.out.println("i187");
System.out.println("i188");
System.out.println("i189");
System.out.println("i190");
System.out.println("i191");
System.out.println("i192");
System.out.println("i193");
System.out.println("i194");
System.out.println("i195");
System.out.println("i196");
System.out.println("i197");
System.out.println("i198");
System.out.println("i199");
System.out.println("i200");
System.out.println("i201");
System.out.println("i202");
System.out.println("i203");
System.out.println("i204");
System.out.println("i205");
System.out.println("i206");
System.out.println("i207");
System.out.println("i208");
System.out.println("i209");
System.out.println("i210");
System.out.println("i211");
System.out.println("i212");
System.out.println("i213");
System.out.println("i214");
System.out.println("i215");
System.out.println("i216");
System.out.println("i217");
System.out.println("i218");
System.out.println("i219");
System.out.println("i220");
System.out.println("i221");
System.out.println("i222");
System.out.println("i223");
System.out.println("i224");
System.out.println("i225");
System.out.println("i226");
System.out.println("i227");
System.out.println("i228");
System.out.println("i229");
System.out.println("i230");
System.out.println("i231");
System.out.println("i232");
System.out.println("i233");
System.out.println("i234");
System.out.println("i235");
System.out.println("i236");
System.out.println("i237");
System.out.println("i238");
System.out.println("i239");
System.out.println("i240");
System.out.println("i241");
System.out.println("i242");
System.out.println("i243");
System.out.println("i244");
System.out.println("i245");
System.out.println("i246");
System.out.println("i247");
System.out.println("i248");
System.out.println("i249");
System.out.println("i250");
System.out.println("i251");
System.out.println("i252");
System.out.println("i253");
System.out.println("i254");
System.out.println("i255");
System.out.println("i256");
System.out.println("i257");
System.out.println("i258");
System.out.println("i259");
System.out.println("i260");
System.out.println("i261");
System.out.println("i262");
System.out.println("i263");
System.out.println("i264");
System.out.println("i265");
System.out.println("i266");
System.out.println("i267");
System.out.println("i268");
System.out.println("i269");
System.out.println("i270");
System.out.println("i271");
System.out.println("i272");
System.out.println("i273");
System.out.println("i274");
System.out.println("i275");
System.out.println("i276");
System.out.println("i277");
System.out.println("i278");
System.out.println("i279");
System.out.println("i280");
System.out.println("i281");
System.out.println("i282");
System.out.println("i283");
System.out.println("i284");
System.out.println("i285");
System.out.println("i286");
System.out.println("i287");
System.out.println("i288");
System.out.println("i289");
System.out.println("i290");
System.out.println("i291");
System.out.println("i292");
System.out.println("i293");
System.out.println("i294");
System.out.println("i295");
System.out.println("i296");
System.out.println("i297");
System.out.println("i298");
System.out.println("i299");
    }
    
}

