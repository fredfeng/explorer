package examples;

import java.util.*;
import java.io.*;

/** an enumeration of the input lines.
 */
class Lines implements Enumeration {

    DataInputStream in;

    Lines(DataInputStream in) {
	this.in = in;
    }

    public boolean hasMoreElements() {
	return true;
    }

    public Object nextElement() {
	try {
	    return in.readLine();
	} catch (IOException ex) {
	    throw new NoSuchElementException();
	}
    }
}

/** a program to convert input lines to upper case
 */
class Caps {

    static String toUpperCase(String s) {
	return s.toUpperCase();
    }

    static boolean nonEmpty(String s) {
	return s.length() != 0;
    }

    static void println(String s) {
	System.out.println(s);
    }

    public static void main(String[] argv) {
	Enumeration lines = new Lines(new DataInputStream(System.in));
	while (lines.hasMoreElements()) {
	    String line = (String)lines.nextElement();
	    if (nonEmpty(line)) {
		System.out.println(line.toUpperCase());
	    } else {
		break;
	    }
	}
    }
}

/** a program to sum up a list of integers
 */
class Adder {

    static boolean nonEmpty(String s) {
	return s.length() != 0;
    }

    public static void main(String[] argv) {
	Enumeration lines = new Lines(new DataInputStream(System.in));
	int sum = 0;
	while (lines.hasMoreElements()) {
	    String line = (String)lines.nextElement();
	    if (nonEmpty(line)) {
		sum = sum + Integer.parseInt(line);
	    } else {
		break;
	    }
	}
	System.out.println(sum);
    }
}






