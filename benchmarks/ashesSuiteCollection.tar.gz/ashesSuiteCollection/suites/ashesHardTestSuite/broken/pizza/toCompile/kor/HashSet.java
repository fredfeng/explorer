// HashSet.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!


package kor;

import java.util.*;

/**
 * Provides an implementation of the Set object using java.util.Hashtable.
 */

public
class HashSet extends Set
{
	Hashtable set;

	public HashSet()
	{
		set = new Hashtable();
	}
	
	public void add(Object obj)
	{
		if(!set.containsKey(obj))
			set.put(obj, obj);
	}
	
	public boolean contains(Object obj)
	{
		return set.contains(obj);
	}

	public void remove(Object obj)
	{
		set.remove(obj);
	}

	public boolean isEmpty()
	{
		return set.isEmpty();
	}
	
	public DynamicList list()
	{
		return DynamicList.ofEnumeration(set.elements());
	}
    
}
