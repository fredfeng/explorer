// Particle.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

package DustV2;

import kor.*;

/**
 * The Particle is the fundamental object on which actions are performed.
 */

class Particle2 
{
    Playfield playfield;
    double charge;
    
    public void setCharge(double newCharge)
    {
        synchronized(playfield)
        {
            playfield.stopSimulatingIfNecessary();
            
            charge = newCharge;
                        
            playfield.updateForces();
            playfield.restartSimulatingIfNecessary();
        }
    }
    

}
