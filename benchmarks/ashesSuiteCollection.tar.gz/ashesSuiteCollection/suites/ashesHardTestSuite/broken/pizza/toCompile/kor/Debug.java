// Debug.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

package kor;

/**
 * The static methods in this class are simply syntactic sugar for throwing
 * runtime exceptions if a condition fails.
 */

public
class Debug
{
    /**
     * Throw a run-time exception if the boolean is value
     */
     
	static public void assert(boolean b)
	{
		if(!b)
		{
			System.out.println("DEBUGGING ASSERTION TRAPPED!  Generating fake run-time " + 
				"exception...");
			
			throw new RuntimeException();
		}
	}

    /**
     * Always throw a run-time exception.  This is useful to put in a switch statement
     * when a default: case should never occur.
     */
     
	static public void trap()
	{
		System.out.println("DEBUGGING TRAP TRIGGERED! Generating fake run-time " + 
			"exception...");
			
		throw new RuntimeException();
	}

    /**
     * Always throw a run-time exception, but give an intelligent message.
     */
     
    static public void trap(String s)
    {
        System.out.println("DEBUGGING TRAP TRIGGERED! " + s);
        
        System.out.println(" Generating fake run-time " + 
			"exception...");
			
		throw new RuntimeException();
    }
}





















