// Dictionary.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!


package kor;

/**
 * An alternative Dictionary class provided in java.util.  The same concept, however:
 * you associate objects (definition objects) to other objects (entries).
 *
 * There are two sets of methods which can be used on a dictionary.  They correspond
 * to different naming conventions, but they do exactly the same thing.
 * 
 *  associate(entry, associate)
 *  associateOf(entry)
 *  isObjAssociated(entry)
 *  listOfEntries()
 *  listOfAssociates()
 * 
 *  define(entry, value)
 *  valueOf(entry)
 *  isObjDefined(entry)
 *  listOfEntries()
 *  listOfValues()
 */

public
abstract class Dictionary
{
    /**
     * Associate a definitional object to an entry.
     */

    abstract
    public void associate(Object entry, Object associate);

    /**
     * Returns the definition of an entry.  
     *
     * @exception RuntimeException  if the entry has no associate.
     */
     
    abstract
    public Object associateOf(Object entry);

    /**
     * Does the entry have an associate?
     */
     
    abstract
    public boolean isObjAssociated(Object entry);

    /**
     * Returns the list of entries of the dictionary.
     */
     
    abstract
    public DynamicList listOfEntries();

    /**
     * Returns the list of definitional objects of the dictionary
     */
     
    abstract
    public DynamicList listOfAssociates();

    /**
     * Returns the size of the dictionary.
     */
     
    abstract
    public int numEntries();
    
    /**
     * Associate a definitional object to an entry.
     */

     
    abstract
    public void define(Object entry, Object value);

    /**
     * Returns the definition of an entry.  
     *
     * @exception RuntimeException  if the entry has no associate.
     */
     
    abstract
    public Object valueOf(Object entry);

    /**
     * Does the entry have an associate?
     */
     
    abstract
    public boolean isObjDefined(Object entry);

    /**
     * Returns the list of entries of the dictionary.
     */
     
    abstract
    public DynamicList listOfValues();

    public String toString()
    {
        return toString("");
    }
    
    public String toString(String entrySeparator)
    {
        DynamicList listOfEntries = listOfEntries();
        StringBuffer buffer = new StringBuffer();
        
        buffer.append("[");
        
        boolean isEmptyList = true;
        
        while(!listOfEntries.isEmpty())
        {
            Object entry = listOfEntries.next();
        
            if(!isEmptyList)
                buffer.append(", " + entrySeparator);    
            
            buffer.append(entry.toString() + "->" + valueOf(entry).toString());
            
            isEmptyList = false;
        }
        
        buffer.append("]");
        
        return buffer.toString();
    }
        
}
