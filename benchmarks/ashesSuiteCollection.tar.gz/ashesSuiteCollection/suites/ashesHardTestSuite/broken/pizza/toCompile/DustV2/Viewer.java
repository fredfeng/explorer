// Viewer.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

package DustV2;

/**
 * This interface is used to give a common foothold to both the ParticleViewer objects and 
 * PlayfieldViewer objects.
 */

interface Viewer
{
    void refreshView();
}
