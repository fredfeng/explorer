// ParticleViewer.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

package DustV2;

import kor.*;
import java.awt.*;
import java.awt.event.*;

/**
 * This is a frame which displays the properties of a particle, and also lets you edit
 * the fields directly.
 */

class ParticleViewer extends Frame implements Viewer,
                                              ActionListener,
                                              ItemListener,
                                              WindowListener
{
    Playfield playfield;
    Particle particle;

    // Controls
    
    TextField chargeText;
    TextField massText;
    double lastDisplayedCharge;
    boolean displayedCharge;
    double lastDisplayedMass;
    boolean displayedMass;
        
    TextField positionXText, positionYText;
    TextField velocityXText, velocityYText;
    TextField accelerationXText, accelerationYText;
    TextField forceXText, forceYText;
    
    boolean wasSelected = false;

    Button dismissButton;

    static {
        WindowPlacer.setTilingRegion("West", 10, 4);
    }
        
    public ParticleViewer(Playfield playfield, Particle particle)
    {
        super("Particle Properties " + "[" + particle.label + "]");
        
        this.playfield = playfield;
        this.particle = particle;

        addWindowListener(this);
                
        setSize(new Dimension(375, 300));
        
        setLayout(new GridLayout(0, 1));
        
        // Charge of Particle
        {
            Panel p = new Panel();
        
            p.setLayout(new FlowLayout());
            p.add(new Label("Charge"));
            p.add(chargeText = new TextField("0", 2));
            chargeText.addActionListener(this);
            
            add(p);
        }
    
        // Mass of Particle
        {
            Panel p = new Panel();
    
            p.setLayout(new FlowLayout());
            p.add(new Label("Mass"));
            p.add(massText = new TextField("1", 4));
            massText.addActionListener(this);          
            add(p);
        }
    
        // Position of Particle
        {
            Panel p = new Panel();
    
            p.setLayout(new FlowLayout());
            p.add(new Label("Position"));
            
            p.add(new Label("X"));
            p.add(positionXText = new TextField("     ", 10));
            p.add(new Label("Y"));
            p.add(positionYText = new TextField("     ", 10));
                
            positionXText.setFont(new Font("Monospaced", Font.PLAIN, 11));
            positionYText.setFont(new Font("Monospaced", Font.PLAIN, 11));
            
            positionXText.addActionListener(this);
            positionYText.addActionListener(this);
            
            add(p);
        }
        
        // Velocity of Particle
        {
            Panel p = new Panel();
    
            p.setLayout(new FlowLayout());
            p.add(new Label("Velocity"));
            
            p.add(new Label("X"));
            p.add(velocityXText = new TextField("     ", 10));
            p.add(new Label("Y"));
            p.add(velocityYText = new TextField("     ", 10));
                
            velocityXText.setFont(new Font("Monospaced", Font.PLAIN, 11));
            velocityYText.setFont(new Font("Monospaced", Font.PLAIN, 11));
            
            velocityXText.addActionListener(this);
            velocityYText.addActionListener(this);
        
            add(p);
        }
    
        // Acceleration of Particle
        {
            Panel p = new Panel();
    
            p.setLayout(new FlowLayout());
            p.add(new Label("Acceleration"));
            
            p.add(new Label("X"));
            p.add(accelerationXText = new TextField("     ", 10));
            p.add(new Label("Y"));
            p.add(accelerationYText = new TextField("     ", 10));
                
            accelerationXText.setFont(new Font("Monospaced", Font.PLAIN, 11));
            accelerationYText.setFont(new Font("Monospaced", Font.PLAIN, 11));
            
            add(p);
        }

        // Force of Particle
        {
            Panel p = new Panel();
    
            p.setLayout(new FlowLayout());
            p.add(new Label("Force"));
            
            p.add(new Label("X"));
            p.add(forceXText = new TextField("     ", 10));
            p.add(new Label("Y"));
            p.add(forceYText = new TextField("     ", 10));
                
            forceXText.setFont(new Font("Monospaced", Font.PLAIN, 11));
            forceYText.setFont(new Font("Monospaced", Font.PLAIN, 11));
            
            add(p);
        }
                
        // Dismiss button
        {
            Panel p = new Panel();
            
            p.setLayout(new FlowLayout());
        
            dismissButton = new Button("Dismiss");
            dismissButton.addActionListener(this);
            p.add(dismissButton);
            
            add(p);
                        
        }    
        
        WindowPlacer.placeWindowAt(this, "West");

        setVisible(true);
        
        particle.viewer = this;
        particle.hasViewer = true;        
        playfield.viewers.add(this);
        
        displayedCharge = false;
        displayedMass = false;
    }
    
    public void dispose()
    {
        particle.viewer = null;
        particle.hasViewer = false;
        playfield.viewers.remove(this);
        super.dispose();
    }
    
    public void refreshView()
    {
        if(!particle.isViewable)
        {
            dispose();
        }
        else {
        
            if(!wasSelected && particle.isSelected)
            {
                setTitle("Particle Properties " + "[" + particle.label + "]" + " (selected)");
                wasSelected = true;
            }
            else if(wasSelected && !particle.isSelected)
            {
                setTitle("Particle Properties " + "[" + particle.label + "]");
                wasSelected = false;
            }

            if(!displayedCharge || lastDisplayedCharge != particle.charge)
            {            
                chargeText.setText(PlayfieldControls.niceStringOfDouble(particle.charge));
                displayedCharge = true;
                lastDisplayedCharge = particle.charge;
            }
            
            if(!displayedMass || lastDisplayedMass != particle.mass)
            {
                massText.setText(PlayfieldControls.niceStringOfDouble(particle.mass));
                displayedMass = true;
                lastDisplayedMass = particle.mass;
            }
            
            positionXText.setText(ExtString.paddedLeftOf(
                new Double(ExtDouble.truncatedOf(particle.posX, 2)).toString(), 7));
                
            positionYText.setText(ExtString.paddedLeftOf(new Double(ExtDouble.truncatedOf(
                    particle.posY, 2)).toString(), 7));
                
            velocityXText.setText(ExtString.paddedLeftOf(
                new Double(ExtDouble.truncatedOf(particle.velX, 2)).toString(), 7));
                
            velocityYText.setText(ExtString.paddedLeftOf(
                new Double(ExtDouble.truncatedOf(particle.velY, 2)).toString(), 7));
                
            accelerationXText.setText(ExtString.paddedLeftOf(
                new Double(ExtDouble.truncatedOf(particle.accX, 2)).toString(), 7));
                
            accelerationYText.setText(ExtString.paddedLeftOf(
                new Double(ExtDouble.truncatedOf(particle.accY, 2)).toString(), 7));
            
            forceXText.setText(ExtString.paddedLeftOf(
                new Double(ExtDouble.truncatedOf(particle.forceX, 2)).toString(), 7));
                
            forceYText.setText(ExtString.paddedLeftOf(
                new Double(ExtDouble.truncatedOf(particle.forceY, 2)).toString(), 7));
        }
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == massText)
        {
            double value = Double.valueOf(massText.getText()).doubleValue();
            
            particle.setMass(value);
            playfield.refreshViewers();   
        }
        else if(e.getSource() == positionXText || 
            e.getSource() == positionYText)
        {
            double x = Double.valueOf(positionXText.getText()).doubleValue();
            double y = Double.valueOf(positionYText.getText()).doubleValue();
            
            particle.moveTo(x, y);
            playfield.refreshViewers();
        }
        else if(e.getSource() == velocityXText ||
            e.getSource() == velocityYText)
        {
            double x = Double.valueOf(velocityXText.getText()).doubleValue();
            double y = Double.valueOf(velocityYText.getText()).doubleValue();
            
            particle.setVelocity(x, y);
            playfield.refreshViewers();
        }
        else if(e.getSource() == chargeText)
        {
            double value = Double.valueOf(chargeText.getText()).doubleValue();
            
            particle.setCharge(value);
            playfield.refreshViewers();
        }
        else if(e.getSource() == dismissButton)
        {
            handleClickToClose();
        }
    }
    
    void handleClickToClose()
    {       
        dispose();
    }
    
    public void itemStateChanged(ItemEvent e)
    {
    }
    
        
    public void windowClosing(WindowEvent e)
    {
        handleClickToClose();
    }
     
    public void windowOpened(WindowEvent e)
    {
    }
     
    public void windowIconified(WindowEvent e)
    {
    }
     
    public void windowDeiconified(WindowEvent e)
    {
    }
     
    public void windowClosed(WindowEvent e)
    {
    }
     
    public void windowActivated(WindowEvent e)
    {
    }
     
    public void windowDeactivated(WindowEvent e) 
    {
    }
}


