// VectorPriorityQueue.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!



package kor;

import java.util.*;

class PrioritizedObject
{
	Object object;
	long priority;
	
	public PrioritizedObject(Object object, long priority)
	{
		this.object = object;
		this.priority = priority;
	}
}

/**
 * Provides an implementation of the PriorityQueue using java.util.Vector
 */

public
class VectorPriorityQueue extends PriorityQueue
{
	Vector queue;	// the first element 0 has the highest priority

	public VectorPriorityQueue()
	{
		queue = new Vector();
	}
	
	public void insert(Object o, long p)
	{
		boolean wasInserted;
		
		wasInserted = false;
		
		for(int i = 0; i < queue.size(); i++)
		{
			if(p > ((PrioritizedObject) queue.elementAt(i)).priority)
			{
				// element should go here
				
				queue.insertElementAt(new PrioritizedObject(o, p), i);
				wasInserted = true;
				break;
			}
		}
		
		if(!wasInserted)
		{
			// Object should go at the end.
			
			queue.addElement(new PrioritizedObject(o, p));
		}
	}
	
    public boolean contains(Object obj) 
    {
        for(int i = 0; i < queue.size(); i++)
        {
            PrioritizedObject p = (PrioritizedObject) queue.elementAt(i);
            
            Object object = p.object;
            long priority = p.priority;
            
            if(object == obj)
                return true;
        }
        
        return false;
    }

    public long priorityOf(Object obj) 
    {
        for(int i = 0; i < queue.size(); i++)
        {
            PrioritizedObject p = (PrioritizedObject) queue.elementAt(i);
            
            Object object = p.object;
            long priority = p.priority;
            
            if(object == obj)
                return priority;
        }
        
        Debug.trap();
        return 0;
    }
	
    public long priorityOfNext()
    {
        PrioritizedObject p = (PrioritizedObject) queue.elementAt(0);
     
        Debug.assert(p != null);
              
        return p.priority;
    }
    
    public void testOrder()
    {
        for(int i = 0; i < queue.size() - 1; i++)
        {
            PrioritizedObject p = (PrioritizedObject) queue.elementAt(i);
            PrioritizedObject q = (PrioritizedObject) queue.elementAt(i+1);
            
            Debug.assert(p.priority < q.priority);
        }   
    }
    
    public Object next()
    {
        Object toReturn = ((PrioritizedObject) queue.elementAt(0)).object;

        queue.removeElementAt(0);

        return toReturn;
    }

	public Object head()
    {
        return queue.firstElement();
    }
    
    public Object tail()
    {
        return queue.lastElement();
    }

    public boolean isEmpty()
    {
        return queue.isEmpty();
    }
        
}
