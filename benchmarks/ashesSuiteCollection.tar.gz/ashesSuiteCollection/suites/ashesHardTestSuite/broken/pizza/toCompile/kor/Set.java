// Set.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

package kor;


/** 
 * A set is just a collection of objects with the obvious methods defined below.
 * Note that a set can only contain up to one instance of the same object.
 */ 

public 
abstract class Set
{
    abstract
    public void add(Object o);

    abstract
    public void remove(Object o);

    abstract
    public boolean contains(Object o);

    abstract
    public boolean isEmpty();

    abstract
    public DynamicList list();

    public String toString()
    {
        return toString("");
    }
    
    public String toString(String entrySeparator)
    {
        DynamicList list = list();
        StringBuffer buffer = new StringBuffer();
        
        buffer.append("[");
        
        boolean isEmptyList = true;
         
        while(!list.isEmpty())
        {
            if(!isEmptyList)
                buffer.append(", " + entrySeparator);
                
            Object obj = list.next();
               
            buffer.append(obj.toString());
            
            isEmptyList = false;
        }
        
        buffer.append("]");
        
        return buffer.toString();
    }    
}
