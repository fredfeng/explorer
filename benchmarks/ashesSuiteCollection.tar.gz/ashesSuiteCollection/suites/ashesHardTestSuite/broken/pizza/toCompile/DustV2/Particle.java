// Particle.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

package DustV2;

import kor.*;

/**
 * The Particle is the fundamental object on which actions are performed.
 */

class Particle 
{
    double posX, posY;
    double velX, velY;
    double forceX, forceY;
    double accX, accY;

    boolean hasTrail;
    CycleQueue traces;

    /* Used to calculate next time step, using the order 4 Runge-Kutta method */

    double workPosX, workPosY;
    double workVelX, workVelY;
    double workForceX, workForceY;
    double workAccX, workAccY;
    
    double originalVelX, originalVelY;
    double originalPosX, originalPosY;
    
    double posXK, posYK;
    double velXK, velYK;
    double sumPosX, sumPosY;
    double sumVelX, sumVelY;


    /* Used for the step size control (also known as adaptive solver) */    
            
    double savedPosX, savedPosY;
    double savedVelX, savedVelY;
    
    double firstPosX, firstPosY;
    double firstVelX, firstVelY;
    
    double charge = 0;
    double mass = 1;
    boolean isAnchored;
    boolean isSelected;

    boolean isViewable = true;
    
    Playfield playfield;
    
    boolean hasViewer;
    ParticleViewer viewer;

    String label;
        
    static
    private VectorPriorityQueue labelQueue = new VectorPriorityQueue(); // of strings

    static
    private HashDictionary prioritiesOfLabels = new HashDictionary();
        
    static
    long priorityCount = 0;
    
    static
    int batchCount = 0;
    
    static {
        createNewBatchOfLabels(null);
    }
    
    static
    void eraseAllLabels()
    {
        batchCount = 0;
        labelQueue = new VectorPriorityQueue();
        prioritiesOfLabels = new HashDictionary();
    }
    
    /**
     * exclusionSet is the set of labels which are already in use.. so don't add them
     * to the pool.
     */
     
    static
    void createNewBatchOfLabels(Set exclusionSet)
    
    {
        for(char label = 'a'; label <= 'z'; label++)
        {
            String newLabel = new Character(label).toString();
          
            if(batchCount != 0)
                newLabel += batchCount;
                  
            if(exclusionSet == null || !exclusionSet.contains(newLabel))
                labelQueue.insert(newLabel, priorityCount);
                
            prioritiesOfLabels.associate(newLabel, new Long(priorityCount));
            priorityCount--;
        }
        
        batchCount++;    
    }
    
    static
    public String nextLabel()
    {
        if(labelQueue.isEmpty())
            createNewBatchOfLabels(null);
        
        return (String) labelQueue.next();
    }
    
    static
    public void relinquishLabel(String label)
    {
        long oldPriority = ((Long) prioritiesOfLabels.associateOf(label)).longValue();
        
        labelQueue.insert(label, oldPriority);
    }
    
    public Particle(Playfield playfield)
    {
        this.playfield = playfield;
        
        traces = new VectorCycleQueue(1);
    }
    
    public void dispose()
    {
        isViewable = false;

        relinquishLabel(label);
    }
    
    public void setSelected(boolean value)
    {
        synchronized(playfield)
        {
            playfield.stopSimulatingIfNecessary();
            
            isSelected = value;
            
            playfield.restartSimulatingIfNecessary();
        }
    }

    public void invalidateScreenTrail()
    {
        DynamicList listOfTraces = traces.list();
        
        while(!listOfTraces.isEmpty())
        {
            Trace t = (Trace) listOfTraces.next();
            
            t.isDrawable = false;
        }
    }
    
    public void setTrail(boolean value)
    {
        synchronized(playfield)
        {
            playfield.stopSimulatingIfNecessary();
            
            hasTrail = value;
            
            if(value)
                traces.setSize(playfield.controls.trailSize);
            else
                traces.setSize(1);
                
            if(isSelected)
            {
                playfield.controls.particleTrailBox.setState(value);
                playfield.controls.particlePopupTrailBox.setState(value);
            }
            
            playfield.restartSimulatingIfNecessary();
        }
    }
    
    public void moveTo(double posX, double posY)
    {
        synchronized(playfield)
        {
            playfield.stopSimulatingIfNecessary();
            
            this.posX = posX;
            this.posY = posY;
            
            this.traces.insert(new Trace(posX, posY));
           
            if(this.hasTrail)
            {
                this.traces.setSize(1);
                this.traces.setSize(playfield.controls.trailSize);
                    // truncates it due to unnatural moving of particle
            }

            playfield.updateForces();
            playfield.restartSimulatingIfNecessary();
        }
    }    
    
    public void setVelocity(double velX, double velY)
    {
        synchronized(playfield)
        {
            playfield.stopSimulatingIfNecessary();
            
            this.velX = velX;
            this.velY = velY;
            
            playfield.updateForces();
            playfield.restartSimulatingIfNecessary();
        }
    }
    
    public void randomizeLocation()
    {
        synchronized(playfield)
        {
            playfield.stopSimulatingIfNecessary();
                
            posX = Math.random() * 16 - 8;
            posY = Math.random() * 16 - 8;
            
            playfield.updateForces();
            playfield.restartSimulatingIfNecessary();
        }
    }
    
    public void randomizeVelocity()
    {
        synchronized(playfield)
        {   
            playfield.stopSimulatingIfNecessary();
                
            velX = Math.random() * 0.2 - 0.1;
            velY = Math.random() * 0.2 - 0.1;
            
            playfield.updateForces();
            playfield.restartSimulatingIfNecessary();
        }
    }
    
    public double distanceTo(double posX, double posY)
    {
        double deltaX = this.posX - posX, 
               deltaY = this.posY - posY;
                   
        return Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    }
    
    public void setMass(double newMass)
    {
        synchronized(playfield)
        {
            playfield.stopSimulatingIfNecessary();
            
            mass = newMass;
            
            playfield.updateForces();
            playfield.restartSimulatingIfNecessary();
        }
    }
    
    public void setAnchored(boolean value)
    {
        synchronized(playfield)
        {
            playfield.stopSimulatingIfNecessary();
            
            isAnchored = value;
            
            playfield.updateForces();
            playfield.restartSimulatingIfNecessary();
        }
    }   

    public void setCharge(double newCharge)
    {
        synchronized(playfield)
        {
            playfield.stopSimulatingIfNecessary();
            
            charge = newCharge;
            
            playfield.updateForces();
            playfield.restartSimulatingIfNecessary();
        }
    }
    
    /**
     * Set the force variables of these two particles experiencing electrical attraction
     * to each other 
     */
     
    public void calculateAttractionTo(Particle other)
    {
        double deltaX, deltaY;
        double squareDist, dist;
        double force, rank, forceX, forceY;
        
        if(this.charge == 0 || other.charge == 0)
        {
            // Nothing to do here, the charges are electrically neutral.
            
            return;
        }   
        
        deltaX = other.workPosX - this.workPosX;
        deltaY = other.workPosY - this.workPosY;
        
        squareDist = deltaX * deltaX + deltaY * deltaY;
        dist = Math.sqrt(squareDist);
        
        rank = Playfield.COULOMB_FACTOR * this.charge * other.charge;
        force = rank / (dist * squareDist);
                
        forceX = force * deltaX;
        forceY = force * deltaY;
     
        other.workForceX += forceX;
        other.workForceY += forceY;
        
        this.workForceX -= forceX;
        this.workForceY -= forceY;   
    }

    public DoublePair electricFieldAt(double x, double y)
    {
        double deltaX, deltaY;
        double squareDist, dist;
        double force, rank, forceX, forceY;
        
        if(this.charge == 0)
        {
            return new DoublePair(0, 0);
        }   
        
        deltaX = x - this.posX;
        deltaY = y - this.posY;
        
        squareDist = deltaX * deltaX + deltaY * deltaY;
        squareDist = Math.max(squareDist, 0.0000000000001);
             // don't want to get a division by zero

        dist = Math.sqrt(squareDist);
        
            
        rank = Playfield.COULOMB_FACTOR * this.charge;
        force = rank / (dist * squareDist);
        
        return new DoublePair(force * deltaX, force * deltaY);
    }
    
    public double potentialEnergyDueTo(Particle other)
    {
        double deltaX, deltaY;
        double squareDist, dist;
        double rank;
        
        if(this.charge == 0 || other.charge == 0)
        {
            // Nothing to do here, the charges are electrically neutral.
            
            return 0;
        }   
        
        deltaX = other.posX - this.posX;
        deltaY = other.posY - this.posY;
        
        dist = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
        
        rank = Playfield.COULOMB_FACTOR * this.charge * other.charge;
        
        return rank / dist;
    }
}
