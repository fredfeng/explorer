// Stack.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!


package kor;

/**
 * An alternative to the Stack class provided in java.util. 
 */
 
public 
abstract class Stack
{
    abstract 
    public boolean isEmpty();
        
    abstract 
    public void push(Object obj);
        
    /**
     * Returns the top of the stack, and removes it from the stack.
     *
     * @exception RuntimeException  if the stack has no elements
     */
     
    abstract 
    public Object pop() throws RuntimeException;
     
    /**
     * Returns the top of the stack, but does not remove it.
     */
     
    abstract 
    public Object top() throws RuntimeException;
}
 
