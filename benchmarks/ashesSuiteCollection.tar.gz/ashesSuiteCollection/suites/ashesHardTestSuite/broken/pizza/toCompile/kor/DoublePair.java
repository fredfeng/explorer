// DoublePair.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!


package kor;

/**
 * Simply a pair of doubles.
 */

public 
class DoublePair
{
    public double x, y;
    
    public DoublePair(double x, double y)
    {
        this.x = x;
        this.y = y;
    }
}
