// OkayDialog.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!


package kor;

import java.awt.*;
import java.awt.event.*;

/**
 * Provides an easy to use dialog which prints one message and has one button
 * to dismiss it.
 */

public 
class OkayDialog extends Dialog implements WindowListener, ActionListener
{
    Button dismissButton;
    
    /**
     * Opens a simple dialog.
     *
     * @param frame  the frame to which this dialog belongs
     * @param title  the title of the dialog
     * @param comment  what message should be displayed in the center of the dialog
     * @param buttonLabel the label of the button to be displayed as the "dismiss" button
     */

    public OkayDialog(Frame frame, String title, String comment, String buttonLabel)
    {
        super(frame, title, false);

        setSize(new Dimension(400, 100));
        setLayout(new GridLayout(0, 1));

        WindowPlacer.placeWindowAt(this, "Center");        
        addWindowListener(this);
        
        // Panel
        {
            Panel p = new Panel();
            
            p.setLayout(new FlowLayout());
            Label textLabel = new Label(comment);
            p.add(textLabel);
            
            add(p);
        }
        
        // Button
        {
            Panel p = new Panel();
            
            p.setLayout(new FlowLayout());
            dismissButton = new Button(buttonLabel);
            dismissButton.addActionListener(this);
            
            p.add(dismissButton);
            
            add(p);
        }
        
        show();
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == dismissButton)
            handleClickToClose(); 
    }

    public void handleClickToClose()
    {
        dispose();
    }    
    
    public void windowClosing(WindowEvent e)
    {
        handleClickToClose();
    }
     
    public void windowOpened(WindowEvent e)
    {
    }
     
    public void windowIconified(WindowEvent e)
    {
    }
     
    public void windowDeiconified(WindowEvent e)
    {
    }
     
    public void windowClosed(WindowEvent e)
    {
    }
     
    public void windowActivated(WindowEvent e)
    {
    }
     
    public void windowDeactivated(WindowEvent e) 
    {
    }
}
