// IntPair.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!


package kor;

/**
 * A container object for a pair of ints.
 */

public
class IntPair
{
    public int x, y;
    
    public IntPair(int x, int y)
    {
        this.x = x;
        this.y = y;
    }
}
