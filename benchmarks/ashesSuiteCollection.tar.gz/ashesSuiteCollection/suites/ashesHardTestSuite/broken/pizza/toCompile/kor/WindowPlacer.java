// WindowPlacer.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!


package kor;

import java.awt.*;

class RegionInfo
// Instance object.
{
    int distanceBetweenTiles;
    int numTiles;
    int maxTiles;
    
    public RegionInfo(int distanceBetweenTiles, int maxTiles)
    {
        this.distanceBetweenTiles = distanceBetweenTiles;
        this.maxTiles = maxTiles;
    }
}

/**
 * Provides simple methods which automatically center windows in various
 * regions of the desktop.
 * 
 * <p> You also have the option to make certain Regions tiled, so that
 * windows of the same size will not perfectly overlap each other if they
 * are placed in the same region.
 *
 * <p> The regions are: North, Northeast, East, Southeast, South, Southwest,
 * West, Northwest, Center.
 * 
 */

public
class WindowPlacer
{
    static
    Dimension screenSize;
    
    static
    int distanceFromEdge = 20;

    static    
    HashDictionary tilingRegions = new HashDictionary();
    
    static {
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        
        screenSize = toolkit.getScreenSize();
    }

    /**
     * Define a region to be a tiled region.
     *
     * @param region which region to tile (see above for names)
     * @param distanceBetweenTiles  how much to displace each window, in pixels
     * @param maxTiles the number of tiles before it cycles
     */
     
    static
    public void setTilingRegion(String region, int distanceBetweenTiles, int maxTiles)
    {
        tilingRegions.associate(region, new RegionInfo(distanceBetweenTiles, maxTiles));
    } 
     
    /**
     * Place a window in a given region.
     */   
     
    static
    public void placeWindowAt(Window w, String s)
    {
        Dimension windowSize = w.getSize();
        int newX, newY;
        
        if(s.equals("Center"))
        {
            newX = (screenSize.width - windowSize.width) / 2;
            newY = (screenSize.height - windowSize.height) / 2;
        }
        else if(s.equals("Northeast"))
        {
            newX = screenSize.width - (distanceFromEdge + windowSize.width);
            newY = distanceFromEdge;
        }
        else if(s.equals("East"))
        {
            newX = screenSize.width - (distanceFromEdge + windowSize.width);
            newY = (screenSize.height - windowSize.height) / 2;
        }
        else if(s.equals("Southeast"))
        {
            newX = screenSize.width - (distanceFromEdge + windowSize.width);
            newY = screenSize.height - (distanceFromEdge + windowSize.height);
        }
        else if(s.equals("South"))
        {
            newX = (screenSize.width - windowSize.width) / 2;
            newY = screenSize.height - (distanceFromEdge + windowSize.height);
        }
        else if(s.equals("Southwest"))
        {
            newX = distanceFromEdge;
            newY = screenSize.height - (distanceFromEdge + windowSize.height);
        }
        else if(s.equals("West"))
        {
            newX = distanceFromEdge;
            newY = (screenSize.height - windowSize.height) / 2;
        }
        else if(s.equals("Northwest"))
        {
            newX = distanceFromEdge;
            newY = distanceFromEdge;
        }
        else {
            newX = 0;
            newY = 0;
            Debug.trap();
        }
        // Modify based on region
        {
            if(tilingRegions.isObjAssociated(s))
            {
                RegionInfo r = (RegionInfo) tilingRegions.associateOf(s);
                
                newX += r.distanceBetweenTiles * r.numTiles;
                newY += r.distanceBetweenTiles * r.numTiles;
                
                r.numTiles++;
                
                if(r.numTiles == r.maxTiles)
                    r.numTiles = 0;
            }
        }
        
        w.setLocation(newX, newY);
    }
}
