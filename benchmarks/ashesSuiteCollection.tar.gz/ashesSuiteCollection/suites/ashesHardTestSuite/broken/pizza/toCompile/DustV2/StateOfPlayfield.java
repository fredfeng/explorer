// StateOfPlayfield.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

package DustV2;

import java.util.*;

class StateOfPlayfield
{
    Vector particles;
}
