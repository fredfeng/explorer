// Queue.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!


package kor;

/**
 * A Queue is simply a FIFO (first in, first out) queue.  The methods below
 * do the expected things.  The head of the queue is defined as the next object
 * to be returned.
 */

public
abstract class Queue
{
    abstract
    public void insert(Object o);

    abstract
    public Object next();
    
    abstract
    public Object head();
    
    abstract
    public Object tail();
    
    abstract
    public boolean isEmpty();
    
    abstract
    public boolean contains(Object o);
}
