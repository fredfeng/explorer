// List.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

package kor;

/**
 * The list object provides an alternative to dealing with enumerations.  Its method names
 * are less cumbersome than those of Enumeration's and there are two subclasses: 
 * StaticList and DynamicList which guarantee certain things about the persistence of the list.
 * See them for more details.
 */
 
public
abstract class List
{
    abstract
    public Object next();
    
    abstract
    public boolean isEmpty();
}
 
