// VectorCycleQueue.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!



package kor;

import java.util.*;

/**
 * Provides an implementation of the CycleQueue using java.util.Vector.
 *
 */
 
public
class VectorCycleQueue extends CycleQueue
{
    private 
    Vector queue;

    private
    int size;
        
    private
    int boundSize;

    public VectorCycleQueue(int boundSize)
    {
        queue = new Vector();
        this.boundSize = boundSize; 
    }
    
    public void setSize(int boundSize)
    {
        this.boundSize = boundSize;

        while(size > boundSize)
        {
            queue.removeElementAt(size-1);
            size--;
        }
    }

    public int getSize()
    {
        return boundSize;
    }
    
    public void insert(Object o)
    {
        queue.insertElementAt(o, 0);
        size++;

        if(size > boundSize)
        {
            queue.removeElementAt(size-1);
            size--;
        }
    } 
    
    public boolean isEmpty()
    {
        return queue.isEmpty();
    }

    /**
     * Returns the list of elements, starting with most recently inserted.
     */

    public DynamicList list()
    {
        return DynamicList.ofEnumeration(queue.elements());
    }    
    
    public boolean contains(Object o)
    {
        return queue.contains(o);
    }
    
    public int size()
    {
        return size;
    }
}
