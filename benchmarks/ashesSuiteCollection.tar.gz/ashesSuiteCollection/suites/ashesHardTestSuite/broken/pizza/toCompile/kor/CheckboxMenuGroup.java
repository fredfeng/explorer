// CheckboxMenuGroup.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!


package kor;

import java.awt.*;
import java.awt.event.*;

/**
 * The CheckboxMenuGroup provides the capabilitity of having mutually exclusive
 * options in a menu, as with a CheckboxGroup.
 * 
 */

public
class CheckboxMenuGroup implements ItemListener
{
    HashSet set = new HashSet();    // of CheckboxMenuItems
    
    public CheckboxMenuGroup()
    {
    }

    /**
     * Adds an option to this menu.
     * 
     * @param s the option
     * @param m the menu which contains these options
     * @param listener object to be notified when an option is selected
     */
     
    public void add(String s, Menu m, ItemListener listener)
    {
        CheckboxMenuItem item = new CheckboxMenuItem(s);

        set.add(item);
        m.add(item);
        
        item.addItemListener(this);
        item.addItemListener(listener);
    }
        
    public void itemStateChanged(ItemEvent e)
    {
        CheckboxMenuItem source = (CheckboxMenuItem) e.getSource();
        
        Debug.assert(set.contains(source));
        
        if(!source.getState())
        {
            // It's not allowed to unselect all the options
            source.setState(true);
        }
        else 
        {
            // Change the state of the other selected box.
            
            DynamicList listOfBoxes = set.list();
            
            while(!listOfBoxes.isEmpty())
            {
                CheckboxMenuItem item = (CheckboxMenuItem) listOfBoxes.next();
                
                if(item.getState() && item != source)
                    item.setState(false);
            }
        }
    }

    /**
     * Returns the currently selected option of this group.
     * 
     * There's no guarantee that this object's actionPerformed method is called before
     * the other hence, don't use getSelected() in an actionPerformed method to find out
     * which one has selected.  (rather, use e.getSource().getLabel())
     */
         
    public String getSelected()
    {
        DynamicList listOfBoxes = set.list();
            
        while(!listOfBoxes.isEmpty())
        {
            CheckboxMenuItem item = (CheckboxMenuItem) listOfBoxes.next();
            
            if(item.getState())
                return item.getLabel();
        }
        
        Debug.trap();
        
        return null;
    }
    
    /**
     * Determines if this CheckboxMenuItem is an item in the group.  Use this when the 
     * itemStateChanged method is called and you want to determine if an object
     * belongs to this group.  <em> Deprecated. Use boolean contains(Object) instead </em>
     */
     
    public boolean isItemInGroup(CheckboxMenuItem desiredItem)
    {
        DynamicList listOfBoxes = set.list();
            
        while(!listOfBoxes.isEmpty())
        {
            CheckboxMenuItem item = (CheckboxMenuItem) listOfBoxes.next();
            
            if(item == desiredItem)
                return true;
        }
        
        return false;
    }

    /**
     * Determines if this CheckboxMenuItem is an item in the group.  Use this when the 
     * itemStateChanged method is called and you want to determine if an object
     * belongs to this group.  
     */

    public boolean contains(Object obj)
    {
        DynamicList listOfBoxes = set.list();
            
        while(!listOfBoxes.isEmpty())
        {
            CheckboxMenuItem item = (CheckboxMenuItem) listOfBoxes.next();
            
            if((Object) item == obj)
                return true;
        }
        
        return false;
    }
    
    /**
     * Set the current selection of this group.
     */
     
    public void setSelected(String s)
    {        
        DynamicList listOfBoxes = set.list();
            
        while(!listOfBoxes.isEmpty())
        {
            CheckboxMenuItem item = (CheckboxMenuItem) listOfBoxes.next();
            
            if(item.getState() && !item.getLabel().equals(s))
                item.setState(false);
            else if(item.getLabel().equals(s))
                item.setState(true);
        }
    }    
}



