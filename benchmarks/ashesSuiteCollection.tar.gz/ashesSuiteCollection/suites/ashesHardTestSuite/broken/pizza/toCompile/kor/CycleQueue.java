// CycleQueue.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!



package kor;

/**
 * A CycleQueue is a queue which keeps the last x elements.  Useful for building 
 * a list of the "last ten elements traversed" or "last ten cities visited".  You 
 * get the idea.
 *
 */

public
abstract class CycleQueue
{
    /**
     * Sets the size of the queue.
     */
     
    abstract
    public void setSize(int size);

    /**
     * Inserts an element at the front of the queue.
     */
     
    abstract
    public void insert(Object o);

    /**
     * Is the queue empty?
     */
     
    abstract
    public boolean isEmpty();

    /**
     * A list of the elements in the queue, from the front to the back (most recent to oldest)
     */
     
    abstract
    public DynamicList list();

    /**
     * Returns the number of elements in the queue.  (be careful, this is not symmetric
     * with setSize() which sets the maximum size of the queue)
     */
     
    abstract
    public int getSize();
    
    /**
     * Does the queue contain this object?
     */
     
    abstract
    public boolean contains(Object o);
}
