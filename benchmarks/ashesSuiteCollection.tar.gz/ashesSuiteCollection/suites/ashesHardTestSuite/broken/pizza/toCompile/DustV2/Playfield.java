// Playfield.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

package DustV2;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

import kor.*;

/**
 * The Playfield is the universe which contains all the particles.  Associated with it is
 * the PlayfieldControls object which handles all the user interface.  The playfield
 * object also has all the simulation handling code. 
 * 
 */

class Playfield 
{    
    static final double COULOMB_FACTOR = 20.0;    
    
    Vector particles;   // of Particles
    
    boolean warnedAboutSingularity;
    boolean careAboutSingularities;
        
    boolean isSimulating = false;
    boolean wasSimulating = false;
    PlayfieldControls controls;
    PlayfieldViewer viewer;
   
    double kineticEnergy;
    double potentialEnergy;

    double lastStepSize = 0;

    Simulation simulation;

    double secsOfCacheReady;
    
    TickMeasurer timeStepTicks = new TickMeasurer(2000);

    kor.HashSet viewers;     // of Viewer
                        
    public Playfield()
    {
        particles = new Vector();
        viewers = new kor.HashSet();
    }

    synchronized        
    public Particle addParticle()
    {
        Particle p = new Particle(this);
        
        p.label = Particle.nextLabel();
        p.posX = 0;
        p.posY = 0;
        
        stopSimulatingIfNecessary();
        particles.addElement(p);
        updateForces();
        restartSimulatingIfNecessary();
        
        return p;
    }
    
    synchronized
    public void deleteParticle(Particle p)
    {
        stopSimulatingIfNecessary();
        particles.removeElement(p);
        updateForces();

        
        restartSimulatingIfNecessary();
        
        p.dispose();
    }

    synchronized
    public void removeAllParticles()
    {
        // Destroy all particles.
        {
            for(int i = 0; i < particles.size(); i++)
            {
                Particle p = (Particle) particles.elementAt(i);
                p.dispose();
            }
        }
        
        particles = new Vector();    
    }
        
    public void restartSimulatingIfNecessary()
    {
        
        if(wasSimulating)
        {
            wasSimulating = false;
            isSimulating = true;
            
            simulation = new Simulation(this);
        }
    }

    public void refreshViewers()
    {
        DynamicList listOfViewers = viewers.list();
        
        while(!listOfViewers.isEmpty())
        {
            Viewer viewer = (Viewer) listOfViewers.next();
            
            viewer.refreshView();
        }
    }    

    public double maxAbsoluteCharge()
    {
        double maxSoFar = 0.0;
        boolean hasFound = false;
        
        for(int i = 0; i < particles.size(); i++)
        {
            Particle p = (Particle) particles.elementAt(i);
            
            if(!hasFound || maxSoFar <= Math.abs(p.charge))
            {
                maxSoFar = Math.abs(p.charge);
                hasFound = true;
            }
        }
        
        return maxSoFar;
    }
    
    public void disposeViewers()
    {
        DynamicList listOfViewers = viewers.list();
        
        while(!listOfViewers.isEmpty())
        {
            Viewer viewer = (Viewer) listOfViewers.next();

            if(viewer instanceof Frame)
                ((Frame) viewer).dispose();
        }
    }    
    
    public void stopSimulatingIfNecessary()
    {
        if(isSimulating)
        {
            isSimulating = false;
            wasSimulating = true;
            
            simulation.stop();
        }
    }
    
    public void startSimulating()
    {
        isSimulating = true;
        simulation = new Simulation(this);
    }
    
    public void stopSimulating()
    {
        simulation.stop();
        isSimulating = false;
    }

    public boolean containsParticles()
    {
        return particles.size() != 0;
    }
    
    public Particle nearestParticleTo(double posX, double posY)
    {
        Particle nearest = null;
        double nearestDistance = 0;
        boolean found = false;
                
        for(int i = 0; i < particles.size(); i++)
        {
            Particle p = (Particle) particles.elementAt(i);
                               
            double distance = p.distanceTo(posX, posY);
                        
            if(!found || distance < nearestDistance)
            {
                nearestDistance = distance;
                nearest = p;
                found = true;
            }
        }
        
        Debug.assert(found);
        
        return nearest;
    } 
        
    /*
    public 
    void run()
    {
        for(;;)
        {     
            if(isSimulating) 
            {                 
                calculateNextTimeStep();
                                
                timeStepTicks.registerTick();
                controls.actualTimeStepRate = timeStepTicks.tickRate();
            }
                
            try {
                if(controls != null && controls.timeStepRate != 0)
                {
                    long timeStepDuration = (long) (1.0/controls.timeStepRate * 1000);
                    Thread.sleep(timeStepDuration);
                }
                else
                    Thread.sleep(500);
            } catch(InterruptedException e) {}
        }
    }
    */
    
    private void calculateTimeStepOfLength(double h)
    {
        // Prepare for Runge-Kutta
        {
            for(int i = 0; i < particles.size(); i++)
            {
                Particle p = (Particle) particles.elementAt(i);
                
                p.originalPosX = p.workPosX;
                p.originalPosY = p.workPosY;
                
                p.originalVelX = p.workVelX;
                p.originalVelY = p.workVelY;
                
            }
        }
        
        // Calculate 'k1'
        {
            calculateAccelerations();
                                
            for(int i = 0; i < particles.size(); i++)
            {
                Particle p = (Particle) particles.elementAt(i);
                
                p.posXK = h * p.workVelX;
                p.posYK = h * p.workVelY;
                
                p.velXK = h * p.workAccX;
                p.velYK = h * p.workAccY;
                
                p.sumPosX = p.posXK;
                p.sumPosY = p.posYK;
                
                p.sumVelX = p.velXK;
                p.sumVelY = p.velYK;
            }
        }
        
        // Calculate 'k2'
        {
            // Advance particles to desired location
            {
                for(int i = 0; i < particles.size(); i++)
                {
                    Particle p = (Particle) particles.elementAt(i);
                
                    p.workPosX = p.originalPosX + 0.5 * p.posXK;
                    p.workPosY = p.originalPosY + 0.5 * p.posYK;
                }
            }
            
            calculateAccelerations();
            
            for(int i = 0; i < particles.size(); i++)
            {
                Particle p = (Particle) particles.elementAt(i);
                
                p.posXK = h * (p.originalVelX + 0.5 * p.velXK);
                p.posYK = h * (p.originalVelY + 0.5 * p.velYK);
                
                p.velXK = h * p.workAccX;
                p.velYK = h * p.workAccY;
                
                p.sumPosX += 2 * p.posXK;
                p.sumPosY += 2 * p.posYK;
                
                p.sumVelX += 2 * p.velXK;
                p.sumVelY += 2 * p.velYK;
            }
        }
        
        // Calculate 'k3'
        {
            // Advance particles to desired location
            {
                for(int i = 0; i < particles.size(); i++)
                {
                    Particle p = (Particle) particles.elementAt(i);
                
                    p.workPosX = p.originalPosX + 0.5 * p.posXK;
                    p.workPosY = p.originalPosY + 0.5 * p.posYK;
                }
            }
            
            calculateAccelerations();
            
            for(int i = 0; i < particles.size(); i++)
            {
                Particle p = (Particle) particles.elementAt(i);
                
                p.posXK = h * (p.originalVelX + 0.5 * p.velXK);
                p.posYK = h * (p.originalVelY + 0.5 * p.velYK);
                
                p.velXK = h * p.workAccX;
                p.velYK = h * p.workAccY;
                
                p.sumPosX += 2 * p.posXK;
                p.sumPosY += 2 * p.posYK;
                
                p.sumVelX += 2 * p.velXK;
                p.sumVelY += 2 * p.velYK;
            }
        }
        
        // Calculate 'k4'
        {
            // Advance particles to desired location
            {
                for(int i = 0; i < particles.size(); i++)
                {
                    Particle p = (Particle) particles.elementAt(i);
                
                    p.workPosX = p.originalPosX + p.posXK;
                    p.workPosY = p.originalPosY + p.posYK;
                }
            }
            
            calculateAccelerations();
            
            for(int i = 0; i < particles.size(); i++)
            {
                Particle p = (Particle) particles.elementAt(i);
                
                p.posXK = h * (p.originalVelX + p.velXK);
                p.posYK = h * (p.originalVelY + p.velYK);
                
                p.velXK = h * p.workAccX;
                p.velYK = h * p.workAccY;
                
                p.sumPosX += p.posXK;
                p.sumPosY += p.posYK;
                
                p.sumVelX += p.velXK;
                p.sumVelY += p.velYK;
            }
        }
        
        // Move particles based on weight average of k1, k2, k3, k4
        {
            double inverseSix = 1.0/6.0;
            
            for(int i = 0; i < particles.size(); i++)
            {
                Particle p = (Particle) particles.elementAt(i);

                if(!p.isAnchored)
                {             
                    p.workPosX = p.originalPosX + p.sumPosX * inverseSix;
                    p.workPosY = p.originalPosY + p.sumPosY * inverseSix;
                    
                    p.workVelX = p.originalVelX + p.sumVelX * inverseSix;
                    p.workVelY = p.originalVelY + p.sumVelY * inverseSix;
                }   
                else {
                    p.workPosX = p.originalPosX;
                    p.workPosY = p.originalPosY;
                    
                    p.workVelX = 0;
                    p.workVelY = 0;
                }
            }
        }
    }

    void calculateEnergyOfSystem()
    {                
        kineticEnergy = 0;
        potentialEnergy = 0;
                
        // Calculate kinetic energy
        {
            for(int i = 0; i < particles.size(); i++)
            {
                Particle p = (Particle) particles.elementAt(i);
                
                kineticEnergy += p.mass * 0.5 * (p.velX * p.velX + p.velY * p.velY);
            }
        }      
        
        // Calculate potential energy due to electric field
        // (note 0 energy is at the center)
        {
            if(controls.electricFieldControl.useExternalField())
            {
                DoublePair field = controls.electricFieldControl.externalField();
                
                for(int i = 0; i < particles.size(); i++)
                {
                    Particle p = (Particle) particles.elementAt(i);
                
                    potentialEnergy += p.charge * (-field.x * p.posX + -field.y * p.posY); 
                }
            }
        }
        
        // Calculate potential energy due to collision with boundary
        {
            if(controls.boundaryControl.useBoundary())
            {
                double radius = controls.boundaryControl.boundaryRadius() - 1;
                double radiusSquared = radius * radius;
                
                for(int i = 0; i < particles.size(); i++)
                {
                    Particle p = (Particle) particles.elementAt(i);
                    
                    double distanceSquared = p.posX * p.posX + p.posY * p.posY;
                    
                    if(distanceSquared >= radiusSquared)
                    {
                        double distance = Math.sqrt(distanceSquared);
                        double force = distance - radius;
                        
                        double energy = Math.pow(force, 7.0) / 7.0;
                        
                        potentialEnergy += energy;
                    }                            
                }
            }
        }

        // Calculate potential energy due to mutual attraction
        {
            for(int i = 0; i < particles.size(); i++)
            {
                Particle particleI = (Particle) particles.elementAt(i);
                
                for(int j = i + 1; j < particles.size(); j++)
                {
                    Particle particleJ = (Particle) particles.elementAt(j);
                    
                    potentialEnergy += particleI.potentialEnergyDueTo(particleJ); 
                }
            }
        }
    }
    
    public DoublePair electricFieldAt(double x, double y)
    {
        DoublePair total = new DoublePair(0, 0);
        
        for(int i = 0; i < particles.size(); i++)
        {
            Particle p = (Particle) particles.elementAt(i);
            DoublePair d = p.electricFieldAt(x, y);
        
            total.x += d.x;
            total.y += d.y;    
        }
        
        if(controls.electricFieldControl.useExternalField())
        {
            DoublePair field = controls.electricFieldControl.externalField();
            
            total.x += field.x;
            total.y += field.y;
        }
        
        return total;
    }
    
    public void calculateNextTimeStep()
    {            
        double desiredTime = controls.simulationSpeed / controls.stepGranularity;
        double totalTime = 0;
        double maxError = controls.simulationPrecision;
        double minError = maxError / 50.0;
        boolean doingFinalAdjustment = false;
        double h;
                
        // Decide what kind of step size to use
            if(lastStepSize == 0)
            {
                h = desiredTime;
            }
            else {
                h = lastStepSize;
                
                if(h > desiredTime)
                    h = desiredTime;
            }
            
        while(totalTime < desiredTime)
        {
            double estError;
            boolean isAcceptable;
            boolean errorIsTooLow;
            
            if(careAboutSingularities)
            {
                if(h < 1e-6 && !warnedAboutSingularity)
                {
                    new OkayDialog(controls.parentDust, 
                        "Warning: headed for singularity?",
                        "Infinite amount of time may be required to compute current paths.", 
                        "Okay");
                        
                    warnedAboutSingularity = true;
                }
            }
                
            // Save current attributes.
            {
                for(int i = 0; i < particles.size(); i++)
                {
                    Particle p = (Particle) particles.elementAt(i);
                            
                    p.savedPosX = p.workPosX;
                    p.savedPosY = p.workPosY;
                    p.savedVelX = p.workVelX;
                    p.savedVelY = p.workVelY;
                }
            }
            
            // Execute first time step.
            {    
                calculateTimeStepOfLength(h);
                
                for(int i = 0; i < particles.size(); i++)
                {
                    Particle p = (Particle) particles.elementAt(i);
                    
                    // Save results
                        p.firstPosX = p.workPosX;
                        p.firstPosY = p.workPosY;
                        p.firstVelX = p.workVelX;
                        p.firstVelY = p.workVelY;
                        
                    // Restore values for next step calculation
                        p.workPosX = p.savedPosX;
                        p.workPosY = p.savedPosY;
                        p.workVelX = p.savedVelX;
                        p.workVelY = p.savedVelY;

                    
                }
            }
                                    
            // Execute time steps
                calculateTimeStepOfLength(h * 0.5);
                calculateTimeStepOfLength(h * 0.5);
                
            // estimate error between two methods, and decide on quality of error
            {
                estError = 0;
                
                for(int i = 0; i < particles.size(); i++)
                {
                    double posError, velError;
                    
                    Particle p = (Particle) particles.elementAt(i);
                    
                    posError = 2 * Math.max(Math.abs(p.firstPosX - p.workPosX),
                        Math.abs(p.firstPosY - p.workPosY));
                    
                    velError = 2 * Math.max(Math.abs(p.firstVelX - p.workVelX),
                        Math.abs(p.firstVelY - p.workVelY));
                        
                    estError = Math.max(Math.max(posError, velError), estError);
                }
                
                estError /= 15;
                    // because the order is 4
                    
                estError /= h;
                
                isAcceptable = estError < maxError;
                errorIsTooLow = estError < minError;
            }
            
            // Handle outcome of error
            {
                if(isAcceptable)
                {
                    totalTime += h;
                    
                    if(errorIsTooLow)
                        h *= 2;
                       
                    if(!doingFinalAdjustment)
                        lastStepSize = h;
                    
                    // Prevent overshoot of desired sample point
                        if(totalTime < desiredTime && (totalTime + h) > desiredTime)
                        {
                            double timeLeft;
                            
                            timeLeft = desiredTime - totalTime;
                                                        
                            if((timeLeft / h) < 0.0001)
                            {
                                // assume it's round off error
                                break;
                            }
                            else {
                                h = desiredTime - totalTime;
                                doingFinalAdjustment = true;
                            }
                        }
                }
                else {                    
                    h /= 2;
                        
                    // Restore values.
                        for(int i = 0; i < particles.size(); i++)
                        {
                            Particle p = (Particle) particles.elementAt(i);
                            
                            p.workPosX = p.savedPosX;
                            p.workPosY = p.savedPosY;
                            p.workVelX = p.savedVelX;
                            p.workVelY = p.savedVelY;
                        }
                }                
            }
        }
        
        // Remember what step size to use next time
            lastStepSize = h;
    }

    /**
     * Called when no simulation is going.
     */
     
    public void updateForces()
    {
        Debug.assert(!isSimulating);
        
        // Get working variables ready for calculation
        {
            for(int i = 0; i < particles.size(); i++)
            {
               Particle p = (Particle) particles.elementAt(i);
                                
                p.workPosX = p.posX;
                p.workPosY = p.posY;
                p.workVelX = p.velX;
                p.workVelY = p.velY;
            }
        }
        
        calculateAccelerations();
        
        // Update force + acceleration based on working variables calcs
        {
            for(int i = 0; i < particles.size(); i++)
            {
               Particle p = (Particle) particles.elementAt(i);
                                
                p.forceX = p.workForceX;
                p.forceY = p.workForceY;
                p.accX = p.workAccX;
                p.accY = p.workAccY;
            }
        }
    }

    /**
     * Determine the accelerations each particle is currently experiencing.
     *
     */
     
    public void calculateAccelerations()
    {
        // Clear all forces.
        {
            for(int i = 0; i < particles.size(); i++)
            {
                Particle p = (Particle) particles.elementAt(i);
                
                p.workForceX = 0;
                p.workForceY = 0;
            }
        }
        
        // External electric field force?
        {
            if(controls.electricFieldControl.useExternalField())
            {
                DoublePair field = controls.electricFieldControl.externalField();
                
                for(int i = 0; i < particles.size(); i++)
                {
                    Particle p = (Particle) particles.elementAt(i);
                
                    p.workForceX += p.charge * field.x;
                    p.workForceY += p.charge * field.y;
                }   
            }
        }
        
        // wall collision force?
        {
            if(controls.boundaryControl.useBoundary())
            {
                double radius = controls.boundaryControl.boundaryRadius() - 1;
                    // -1 here because the raising to the power of 6 of the force
                    // causes forces below 1 to be negligeable
                double radiusSquared = radius * radius;
                
                for(int i = 0; i < particles.size(); i++)
                {
                    Particle p = (Particle) particles.elementAt(i);
                    double distanceSquared = p.workPosX * p.workPosX + p.workPosY * p.workPosY;
                    
                    if(distanceSquared >= radiusSquared)
                    {
                        double distance = Math.sqrt(distanceSquared);
                        double force = distance - radius;
                        
                        force = Math.pow(force, 6.0);
                        
                        double dirX = -p.workPosX / distance;
                        double dirY = -p.workPosY / distance;
                        
                        p.workForceX += dirX * force;
                        p.workForceY += dirY * force;
                    }           
                }
            }
        }

       
        // Viscosity
        {
            if(controls.extrasViscosity != 0)
            {
                double viscosity = controls.extrasViscosity;

                for(int i = 0; i < particles.size(); i++)
                {
                    Particle p = (Particle) particles.elementAt(i);
                    double speedSquared = p.workVelX * p.workVelX + p.workVelY * p.workVelY;
                    
                    if(speedSquared >= 0.0000001)
                    {
                        double speed = Math.sqrt(speedSquared);
                        double force = speed * viscosity;
                        
                        double dirX = -p.workVelX / speed;
                        double dirY = -p.workVelY / speed;
                        
                        p.workForceX += dirX * force;
                        p.workForceY += dirY * force;
                    }           
                }
            }
        }
        

        // Calculate eletrical attraction
        {
            for(int i = 0; i < particles.size(); i++)
            {
                Particle particleI = (Particle) particles.elementAt(i);
                
                for(int j = i + 1; j < particles.size(); j++)
                {
                    Particle particleJ = (Particle) particles.elementAt(j);
                    
                    particleI.calculateAttractionTo(particleJ); 
                }
            }
        }
        
        // Calculate accelerations
        {
            for(int i = 0; i < particles.size(); i++)
            {
                Particle p = (Particle) particles.elementAt(i);
                double inverseMass = 1.0 / p.mass;
                
                p.workAccX = p.workForceX * inverseMass;
                p.workAccY = p.workForceY * inverseMass;
            }
        }
    }    
    
    public void clearTrails()
    {
        synchronized(this)
        {
            stopSimulatingIfNecessary();
            
            // Resize the trails of each particle.
            {
                for(int i = 0; i < particles.size(); i++)
                {
                    Particle p = (Particle) particles.elementAt(i);
                    
                    if(p.hasTrail)
                    {
                        p.traces.setSize(1);
                        p.traces.setSize(controls.trailSize);
                    }
                }
            }
            
            restartSimulatingIfNecessary();
        }
    }
    
    public void resizeTrails()
    {
        synchronized(this)
        {
            stopSimulatingIfNecessary();
            
            // Resize the trails of each particle.
            {
                for(int i = 0; i < particles.size(); i++)
                {
                    Particle p = (Particle) particles.elementAt(i);
                    
                    if(p.hasTrail)
                        p.traces.setSize(controls.trailSize);
                }
            }
            
            restartSimulatingIfNecessary();
        }
    }
    
    public void setAllTrails(boolean value)
    {
        synchronized(this)
        {
            stopSimulatingIfNecessary();
            
            for(int i = 0; i < particles.size(); i++)
            {
                Particle p = (Particle) particles.elementAt(i);
            
                p.setTrail(value);    
            }
            
            restartSimulatingIfNecessary();
        }
    }    

    synchronized
    public void saveStateToStream(OutputStreamWriter outputStreamWriter)
    {
        saveStateToStream(outputStreamWriter, false);
    }

    synchronized   
    public void saveStateToStream(OutputStreamWriter outputStreamWriter, boolean hasTextFiles)
    {
        stopSimulatingIfNecessary();
 
        PrintWriter out = new PrintWriter(outputStreamWriter, true);
       
        out.println("numParticles = " + particles.size());
           
        // Print information for each particle
        {
            for(int i = 0; i < particles.size(); i++)
            {
                Particle p = (Particle) particles.elementAt(i);
                
                out.println();
                
                out.println("particleID = " + i);
                out.println("name = " + p.label);
                out.println("trail = " + p.hasTrail);
                out.println("anchored = " + p.isAnchored);
                out.println("charge = " + p.charge);
                out.println("mass = " + p.mass);
                out.println("posX = " + p.posX);
                out.println("posY = " + p.posY);
                out.println("velX = " + p.velX);
                out.println("velY = " + p.velY);
            } 
        }
        
        out.println("");
        
        out.println("simulationSpeed = " + controls.simulationSpeed);
        out.println("simulationPrecision = " + controls.simulationPrecision);
        out.println("refreshRate = " + controls.stepGranularity);
        out.println("cacheSize = " + controls.simulationCacheSize);
        out.println("singularityWarning = " + 
            controls.simulationSingularityWarningBox.getState());
        out.println("");
        out.println("useGrid = " + controls.viewUseGridBox.getState());
        out.println("gridType = " + controls.viewGridTypeGroup.getSelected());
        out.println("gridDisplacementX = " + controls.displacementX);
        out.println("gridDisplacementY = " + controls.displacementY);
        out.println("snapClicksToGrid = " + controls.viewLockGridBox.getState());
        out.println("zoomControl = " + controls.zoomControl.zoomFactor());
        out.println("gridSize = " + controls.gridSize);
    
        out.println("");
        out.println("positionVectors = " + controls.viewPositionGroup.getSelected());
        out.println("velocityVectors = " + controls.viewVelocityGroup.getSelected());
        out.println("forceVectors = " + controls.viewForceGroup.getSelected());
        out.println("accelerationVectors = " + controls.viewAccelerationGroup.
            getSelected());
        
        out.println("hideVectors = " + 
            controls.viewNoVectorsWhileSimulatingBox.getState());

        out.println("");
        out.println("trailLength = " + controls.trailSizeInSecs);
        out.println("");

        out.println("showName = "  + controls.viewShowLabelsBox.getState());
        out.println("showCharge = "  + controls.viewShowChargeBox.getState());
        out.println("showMass = " + controls.viewShowMassBox.getState());
        out.println("showPosition = " + controls.viewShowPositionBox.getState());
        out.println("showVelocity = " + controls.viewShowVelocityBox.getState());
        out.println("hideInfo = " + controls.viewNoInfoWhileSimulatingBox.getState());
        
        out.println("");
        
        out.println("showElectricField = " + 
            controls.extrasShowElectricFieldBox.getState());
        
        out.println("externalElectricFieldDir = " + 
            controls.electricFieldControl.dir);
            
        out.println("externalElectricFieldMag = " + 
            controls.electricFieldControl.magnitude);
            
        out.println("externalElectricFieldOn = " + 
            controls.electricFieldControl.useBox.getState());
            
        out.println("");
        
        out.println("viscosity = " + controls.extrasViscosity);
        
        out.println("useBoundary = " + controls.boundaryControl.useBoundary());
        out.println("boundaryRadius = " + controls.boundaryControl.boundaryRadius());
        
        out.println("");
        
        Dimension size = viewer.getSize();
        
        out.println("playfieldWidth = " + size.width);
        out.println("playfieldHeight = " + size.height);

        if(hasTextFiles)
        {
            out.print("preSimulationText = ");
            
            if(controls.lessonControl.preSimTextFileName == null)
                out.println("none");
            else
                out.println(controls.lessonControl.preSimTextFileName);
            
            out.print("postSimulationText = ");
            
            if(controls.lessonControl.postSimTextFileName == null)
                out.println("none");
            else
                out.println(controls.lessonControl.postSimTextFileName);
        }        
        
        restartSimulatingIfNecessary();
    }

    public void restoreStateFromStream(InputStreamReader in)
    {
        StreamTokenizer inTokens = new StreamTokenizer(in);
        
        inTokens.resetSyntax();
        inTokens.whitespaceChars(' ', ' ');
        inTokens.whitespaceChars('\t', '\t');
        inTokens.whitespaceChars('\r', '\r');
        inTokens.whitespaceChars('\n', '\n');
        inTokens.wordChars(33, 127);
        
        synchronized(this)
        {
            if(isSimulating)
                controls.handleStopSimulationClick();
            
            // Destroy all particles.
            {
                for(int i = 0; i < particles.size(); i++)
                {
                    Particle p = (Particle) particles.elementAt(i);
                    p.dispose();
                }
                
                particles = new Vector();
            }

            Particle.eraseAllLabels();
            kor.Set usedLabels = new kor.HashSet();
                        
            try {
                Particle currentParticle = null;
                double electricFieldDir = 0.0;
                
                for(;;)
                {
                    // A state file consists of variables assigned values.
                    
                    String name, value;
                    
                    // Get name of variable
                    {
                        inTokens.nextToken();
                        
                        if(inTokens.ttype == StreamTokenizer.TT_EOF)
                            break;
                        
                        Debug.assert(inTokens.ttype == StreamTokenizer.TT_WORD);
                        
                        name = inTokens.sval;
                    }
                    
                    // Get '='
                    {    
                        inTokens.nextToken();
                        
                        Debug.assert(inTokens.ttype == StreamTokenizer.TT_WORD &&
                            inTokens.sval.equals("="));
                    }
                    
                    // Get value   
                    {
                        inTokens.nextToken();
                        
                        Debug.assert(inTokens.ttype == StreamTokenizer.TT_WORD);
                        value = inTokens.sval;
                    }

                    // Process name and value
                    { 
                        if(name.equals("numParticles"))
                        {
                            // ignore for now
                        }
                        else if(name.equals("particleID"))
                        {
                            currentParticle = new Particle(this);
                            particles.insertElementAt(currentParticle, 
                                new Integer(value).intValue());
                        }
                        else if(name.equals("name"))
                        {
                            currentParticle.label = value;
                            usedLabels.add(value);
                        }
                        else if(name.equals("trail"))
                        {
                            currentParticle.hasTrail = new Boolean(value).booleanValue();
                        }
                        else if(name.equals("anchored"))
                        {
                            currentParticle.isAnchored = new Boolean(value).booleanValue();
                        }
                        else if(name.equals("charge"))
                        {
                            currentParticle.charge = new Double(value).doubleValue();
                        }
                        else if(name.equals("mass"))
                        {
                            currentParticle.mass = new Double(value).doubleValue();
                        }
                        else if(name.equals("posX"))
                        {
                            currentParticle.posX = new Double(value).doubleValue();
                        }
                        else if(name.equals("posY"))
                        {
                            currentParticle.posY = new Double(value).doubleValue();
                            currentParticle.moveTo(currentParticle.posX, currentParticle.posY);
                        }
                        else if(name.equals("velX"))
                        {
                            currentParticle.velX = new Double(value).doubleValue();
                        }
                        else if(name.equals("velY"))
                        {
                            currentParticle.velY = new Double(value).doubleValue();
                        }
                        else if(name.equals("simulationSpeed"))
                        {
                            controls.simulationSpeedGroup.setSelected(
                                controls.simulationSpeedGroup.closestItemToValue(
                                new Double(value).doubleValue()));
                                
                            controls.simulationSpeed = 
                                controls.simulationSpeedGroup.valueOfSelected();
                                
                            controls.mainPopupSimulationSpeedGroup.setSelected(
                                controls.simulationSpeedGroup.getSelected());
                        }
                        else if(name.equals("simulationPrecision"))
                        {
                            controls.simulationPrecisionGroup.setSelected(
                                controls.simulationPrecisionGroup.closestItemToValue(
                                new Double(value).doubleValue()));
                                
                            controls.simulationPrecision = 
                                controls.simulationPrecisionGroup.valueOfSelected();
                        }
                        else if(name.equals("refreshRate"))
                        {
                            controls.simulationRefreshGroup.setSelected(
                                controls.simulationRefreshGroup.closestItemToValue(
                                new Double(value).doubleValue()));
                                
                            controls.stepGranularity = (int)
                                controls.simulationRefreshGroup.valueOfSelected();
                        }
                        else if(name.equals("cacheSize"))
                        {
                            controls.simulationCacheSizeGroup.setSelected(
                                controls.simulationCacheSizeGroup.closestItemToValue(
                                new Double(value).doubleValue()));
                            
                            controls.simulationCacheSize = (int)
                                controls.simulationCacheSizeGroup.valueOfSelected();
                        }
                        else if(name.equals("singularityWarning"))
                        {
                            controls.simulationSingularityWarningBox.setState(new 
                                Boolean(value).booleanValue());
                        }
                        else if(name.equals("useGrid"))
                        {
                            controls.viewUseGridBox.setState(new Boolean(value).booleanValue());
                        }
                        else if(name.equals("gridType"))
                        {
                            controls.viewGridTypeGroup.setSelected(value);
                        }
                        else if(name.equals("gridDisplacementX"))
                        {
                            controls.displacementX = new Double(value).doubleValue();
                        }
                        else if(name.equals("gridDisplacementY"))
                        {
                            controls.displacementY = new Double(value).doubleValue();
                        }
                        else if(name.equals("snapClicksToGrid"))
                        {
                            controls.viewLockGridBox.setState(new Boolean(value).booleanValue());
                        }
                        else if(name.equals("zoomControl"))
                        {
                            controls.zoomControl.setZoomFactor(new Double(value).doubleValue());
                        }
                        else if(name.equals("gridSize"))
                        {
                            controls.viewGridSizeGroup.setSelected(
                                controls.viewGridSizeGroup.closestItemToValue(
                                new Double(value).doubleValue()));
                            
                            controls.gridSize = 
                                controls.viewGridSizeGroup.valueOfSelected();
                        }
                        else if(name.equals("positionVectors"))
                        {
                            controls.viewPositionGroup.setSelected(value);
                        }
                        else if(name.equals("velocityVectors"))
                        {
                            controls.viewVelocityGroup.setSelected(value);
                        }
                        else if(name.equals("accelerationVectors"))
                        {
                            controls.viewAccelerationGroup.setSelected(value);
                        }
                        else if(name.equals("forceVectors"))
                        {
                            controls.viewForceGroup.setSelected(value);
                        }
                        else if(name.equals("hideVectors"))
                        {
                            controls.viewNoVectorsWhileSimulatingBox.setState(
                                new Boolean(value).booleanValue());
                        }
                        else if(name.equals("trailLength"))
                        {
                            controls.viewTrailSizeGroup.setSelected(
                                controls.viewTrailSizeGroup.closestItemToValue(
                                new Double(value).doubleValue()));
                            
                            controls.trailSizeInSecs = 
                                (int) controls.viewTrailSizeGroup.valueOfSelected();
                            
                            controls.trailSize = controls.trailSizeInSecs * 
                                controls.stepGranularity;
                        }
                        else if(name.equals("showName"))
                        {
                            controls.viewShowLabelsBox.setState(new 
                                Boolean(value).booleanValue());
                        }
                        else if(name.equals("showCharge"))
                        {
                            controls.viewShowChargeBox.setState(new
                                Boolean(value).booleanValue());
                        }
                        else if(name.equals("showMass"))
                        {
                            controls.viewShowMassBox.setState(new
                                Boolean(value).booleanValue());
                        }
                        else if(name.equals("showPosition"))
                        {
                            controls.viewShowPositionBox.setState(new
                                Boolean(value).booleanValue());
                        }
                        else if(name.equals("showVelocity"))
                        {
                            controls.viewShowVelocityBox.setState(new
                                Boolean(value).booleanValue());
                        }
                        else if(name.equals("hideInfo"))
                        {
                            controls.viewNoInfoWhileSimulatingBox.setState(new Boolean(value).
                                booleanValue());
                        }
                        else if(name.equals("showElectricField"))
                        {
                            controls.extrasShowElectricFieldBox.setState(new Boolean(value).
                                booleanValue());
                        }
                        else if(name.equals("externalElectricFieldDir"))
                        {
                            electricFieldDir = new Double(value).doubleValue();
                        }
                        else if(name.equals("externalElectricFieldMag"))
                        {
                            controls.electricFieldControl.setExternalField(electricFieldDir,
                                new Double(value).doubleValue());
                        }
                        else if(name.equals("externalElectricFieldOn"))
                        {
                            controls.electricFieldControl.setUseExternalField(new 
                                Boolean(value).booleanValue());
                        }
                        else if(name.equals("viscosity"))
                        {
                            controls.extrasViscosityGroup.setSelected(
                                controls.extrasViscosityGroup.closestItemToValue(
                                new Double(value).doubleValue()));
                            
                            controls.extrasViscosity = 
                                controls.extrasViscosityGroup.valueOfSelected();
                        }
                        else if(name.equals("useBoundary"))
                        {
                            controls.boundaryControl.setUseBoundary(
                                new Boolean(value).booleanValue());
                        }
                        else if(name.equals("boundaryRadius"))
                        {
                            controls.boundaryControl.setBoundaryRadius(
                                new Double(value).doubleValue());
                        }
                        else if(name.equals("preSimulationText"))
                        {
                            controls.lessonControl.preSimTextFileName = value;
                        }
                        else if(name.equals("postSimulationText"))
                        {
                            controls.lessonControl.postSimTextFileName = value;
                        }
                        else if(name.equals("playfieldWidth"))
                        {
                            // not used for now
                        }
                        else if(name.equals("playfieldHeight"))
                        {
                            // not used for now
                        }
                        else 
                            Debug.trap("Unrecognized variable in state file: " + name);   
                    }                    
                }
                
                in.close();
            } catch(IOException e){}

            Particle.createNewBatchOfLabels(usedLabels);
                        
            updateForces();                
        }
    }
}

