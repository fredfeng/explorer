// PriorityQueue.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!


package kor;

/**
 * A PriorityQueue is a queue in which every element has an integer associated with it
 * (its priority) and they are ordered in increasing order.
 *
 * <p>Tip: use negative numbers to achieve decreasing order.  
 */


public
abstract class PriorityQueue
{
    /**
     * Insert an object with a given priority into this queue.
     */
     
    abstract
    public void insert(Object o, long priority);

    /**
     * Extracts the next object in the queue and returns it.
     */
     
    abstract
    public Object next();
    
    /**
     * Returns the object which is going to be returned by the next() method,
     * without extracting it from the queue. 
     */
     
    abstract
    public Object head();
    
    /**
     * Returns the last object in the queue.
     */
     
    abstract
    public Object tail();
    
    /**
     * Is this queue empty?
     */
     
    abstract
    public boolean isEmpty();
    
    /**
     * Does this queue contain the given object?
     */
     
    abstract
    public boolean contains(Object o);
    
    /**
     * Returns the priority of an object.
     */
     
    abstract
    public long priorityOf(Object o);
    
    
    /**
     * Returns the priority of the object which is going to be returned next.
     */
     
    abstract
    public long priorityOfNext();
}
