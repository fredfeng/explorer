// PlayfieldViewer.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

package DustV2;

import java.util.*;
import java.awt.*;
import java.awt.event.*;

import kor.*;

/**
 * The PlayfieldViewer object is responsible for displaying the contents of the Playfield
 * in a canvas.
 */

class PlayfieldViewer extends Canvas implements Viewer
{
    static final double MIN_ZOOM_FOR_GRID = 0.35;
    static final int FIELD_ARROW_SIZE = 13;
    static final int FIELD_ARROW_HEAD_SIZE = 4;

    Playfield playfield;

    Image backImage;
    boolean wasBackImageAllocated = false;

    Image gridImage;
    boolean wasGridImagePrepared = false;

    boolean wasGridImagePreparedWithLines = false;

    boolean useBoundary;
    double boundaryRadius;
    
    double gridSize;
    double zoomFactor;

    boolean useGrid;
    
    double displacementX, displacementY;
    
    int canvasHeight, 
        canvasWidth;
    
    TickMeasurer refreshTicks = new TickMeasurer(2000);
    
    public PlayfieldViewer(Playfield playfield)
    {
        this.playfield = playfield;
        this.addMouseListener(playfield.controls);
        this.addMouseMotionListener(playfield.controls);
        
        playfield.viewer = this;
             
        add(playfield.controls.mainPopupMenu);
        add(playfield.controls.particlePopupMenu);
      
        setBackground(Color.black);
        
        playfield.viewers.add(this);
    }
                    
    public void update(Graphics g)
    {        
        paint(g);
    }
    
    public void refreshView()
    {   
        repaint();
    }
    
    
    public void processMouseEvent(MouseEvent e) 
    {
        if (e.isPopupTrigger()) 
            playfield.controls.mousePressed(e);
        
        super.processMouseEvent(e);
    }


    public void paint(Graphics g)
    {           
        // System.out.println("RepaintPriority: " + Thread.currentThread().getPriority());

        synchronized(playfield)
        {            
            boolean canvasSizeChanged = false;
            boolean zoomFactorChanged;
            boolean displacementChanged;
            Graphics activeGraphics = g;
            
            // Allocate (or re-allocate) backImage.
            {          
                Dimension d = getSize();
                
                // Check if canvas size changed.
                    if(d.height != canvasHeight || d.width != canvasWidth)
                    {
                        canvasHeight = d.height;
                        canvasWidth = d.width;
                        
                        canvasSizeChanged = true;
                    }   
                    
                // Arrange for graphics drawing area.
                    if(canvasSizeChanged || !wasBackImageAllocated)
                    {
                        backImage = createImage(canvasWidth, canvasHeight);
                        wasBackImageAllocated = true;
                                                
                        System.gc();
                            // to give a chance to recover lost bitmap image
                    }
            }
            
            // Reset trails if necessary
            {
                zoomFactorChanged = playfield.controls.zoomControl.zoomFactor() != zoomFactor;
                zoomFactor = playfield.controls.zoomControl.zoomFactor();
           
                displacementChanged = (displacementX != playfield.controls.displacementX ||
                    displacementY != playfield.controls.displacementY);
                        
                displacementX = playfield.controls.displacementX;
                displacementY = playfield.controls.displacementY;
                     
                if(zoomFactorChanged || displacementChanged || canvasSizeChanged)
                {
                    for(int i = 0; i < playfield.particles.size(); i++)
                    {
                        Particle p = (Particle) playfield.particles.elementAt(i);
                        
                        p.invalidateScreenTrail();
                    }
                }
            }
        
            // Prepare grid image(background image)
            {
                boolean gridSizeChanged, gridTypeChanged, 
                    boundaryRadiusChanged, boundaryUseChanged;
                                    
                gridSizeChanged = playfield.controls.gridSize != gridSize;
                gridTypeChanged = (playfield.controls.viewGridTypeGroup.getSelected().
                    equals("Lines"))
                        != wasGridImagePreparedWithLines ||
                        useGrid != playfield.controls.viewUseGridBox.getState();

                boundaryRadiusChanged = (playfield.controls.boundaryControl.boundaryRadius()
                    != boundaryRadius || playfield.controls.boundaryControl.useBoundary() !=
                    useBoundary);
                  
                if(canvasSizeChanged || !wasGridImagePrepared ||
                    gridSizeChanged || zoomFactorChanged || gridTypeChanged ||
                        displacementChanged || boundaryRadiusChanged)
                {
                    gridImage = createImage(canvasWidth, canvasHeight);
                    wasGridImagePrepared = true;
                    wasGridImagePreparedWithLines = (playfield.controls.viewGridTypeGroup.
                        getSelected().equals("Lines"));
                    gridSize = playfield.controls.gridSize;
                    useGrid = playfield.controls.viewUseGridBox.getState();
                    
                    useBoundary = playfield.controls.boundaryControl.useBoundary();
                    boundaryRadius = playfield.controls.boundaryControl.boundaryRadius();
                    
                    System.gc();
                        // to give a chance to recover lost bitmap image
                       
                    // Render grid
                    {
                        Graphics ig = gridImage.getGraphics();
                         
                        int centerX = canvasWidth / 2;
                        int centerY = canvasHeight / 2;
                    
                        if(playfield.controls.viewGridTypeGroup.getSelected().equals("Lines") &&
                            playfield.controls.viewUseGridBox.getState() &&
                            zoomFactor >= MIN_ZOOM_FOR_GRID)
                        {
                            // Draw center lines
                            {
                                ig.setColor(Color.lightGray);
                            
                                IntPair pair = screenCoordsOfWorld(0, 0);
                                
                                if(pair.x >= 0 && pair.x < canvasWidth)
                                    ig.drawLine(pair.x, 0, pair.x, canvasHeight);
                                
                                if(pair.y >= 0 && pair.y < canvasWidth)
                                    ig.drawLine(0, pair.y, canvasWidth, pair.y);
                            }
                                                            
                            ig.setColor(Color.gray);
                            
                            // Draw right hand vertical lines    
                            {
                                double atPosX = 0.0;
                                
                                for(;;)
                                {
                                    atPosX += gridSize;
                                    
                                    IntPair pair = screenCoordsOfWorld(atPosX, 0);
                                                                        
                                    if(pair.x >= canvasWidth)
                                        break;
                                        
                                    ig.drawLine(pair.x, 0, pair.x, canvasHeight);
                                }
                            }
                            
                            // Draw right hand vertical lines    
                            {
                                double atPosX = 0.0;
                                
                                for(;;)
                                {
                                    atPosX -= gridSize;
                                    
                                    IntPair pair = screenCoordsOfWorld(atPosX, 0);
                                                                        
                                    if(pair.x < 0)
                                        break;
                                        
                                    ig.drawLine(pair.x, 0, pair.x, canvasHeight);
                                }
                            }
                            
                            // Draw top horizontal line;
                            {
                                double atPosY = 0.0;
                                
                                for(;;)
                                {
                                    atPosY -= gridSize;
                                    
                                    IntPair pair = screenCoordsOfWorld(0, atPosY);
                                                                        
                                    if(pair.y >= canvasHeight)
                                        break;
                                        
                                    ig.drawLine(0, pair.y, canvasWidth, pair.y);
                                }
                            }
                            
                            // Draw bottom horizontal line;
                            {
                                double atPosY = 0.0;
                                
                                for(;;)
                                {
                                    atPosY += gridSize;
                                    
                                    IntPair pair = screenCoordsOfWorld(0, atPosY);
                                                                        
                                    if(pair.y < 0)
                                        break;
                                        
                                    ig.drawLine(0, pair.y, canvasWidth, pair.y);
                                }
                            }
                        }
                        else if(playfield.controls.viewUseGridBox.getState() &&
                            zoomFactor >= MIN_ZOOM_FOR_GRID)
                        {
                            double atPosX = 0.0;
                                                                                        
                            for(;;)
                            {
                                IntPair pair = screenCoordsOfWorld(atPosX, 0);
                                IntPair pair2 = screenCoordsOfWorld(-atPosX, 0);
                                
                                if(pair.x > canvasWidth && pair2.x < 0)
                                    break;
                                
                                // draw the points for both lines (-pair.x, t), and (pair.x, t)
                                {
                                    double atPosY = 0.0;
                                    
                                    for(;;)
                                    {
                                        IntPair pair3 = screenCoordsOfWorld(0, atPosY);
                                        IntPair pair4 = screenCoordsOfWorld(0, -atPosY);
                                        
                                        if(pair3.y < 0 && pair4.y > canvasHeight)
                                            break;
                                    
                                        if(atPosX == 0 || atPosY == 0)
                                            ig.setColor(Color.lightGray);
                                        else
                                            ig.setColor(Color.gray);

                                        if(pair3.y >= 0)
                                        {
                                            ig.drawLine(pair.x, pair3.y, pair.x, pair3.y);
                                            ig.drawLine(pair2.x, pair3.y, pair2.x, pair3.y);
                                        }
                                        
                                        if(pair4.y <= canvasHeight)
                                        {
                                            ig.drawLine(pair.x, pair4.y, pair.x, pair4.y);
                                            ig.drawLine(pair2.x, pair4.y, pair2.x, pair4.y);
                                        }
                                        
                                        atPosY += gridSize;
                                    }
                                }
                                
                                atPosX += gridSize;
                            }
                            
                        }
                        
                        if(playfield.controls.boundaryControl.useBoundary() &&
                            playfield.controls.boundaryControl.displayBoundary())
                        {
                            IntPair pair = screenCoordsOfWorld(0, 0);
                            
                            double boundaryRadius = playfield.controls.
                                boundaryControl.boundaryRadius(); 
                            
                            int screenRadius = screenDistanceOfWorldDistance(boundaryRadius);
                            
                            ig.setColor(Color.lightGray);
                            ig.drawOval(pair.x - screenRadius, pair.y - screenRadius, 
                                screenRadius * 2, screenRadius * 2);
                        }
                    }    
                } 
            }
            
            // Get g ready to render.
            {
                g = backImage.getGraphics();

                g.drawImage(gridImage, 0, 0, this);
                
                /*
                // Build a tracker, to wait for grid to be copied.
			    {
			       	MediaTracker tracker = new MediaTracker(this);
			    
			    	tracker.addImage(gridImage, 0);
				
	        	    try {
			       		tracker.waitForAll();
			    	} catch(InterruptedException e){}
			    }   
                */            
            }
         
            // Render electric field if necessary
            {
                if(playfield.controls.extrasShowElectricFieldBox.getState())
                {                    
                    double maxCharge = Math.max(playfield.maxAbsoluteCharge(), 1.0);
                    double worldSizeOfArrow = worldDistanceOfScreenDistance(FIELD_ARROW_SIZE);
                    
                    double maxMagnitude = Playfield.COULOMB_FACTOR * maxCharge;
                    
                    for(int atX = 0; atX < canvasWidth; atX += FIELD_ARROW_SIZE)
                        for(int atY = 0; atY < canvasHeight; atY += FIELD_ARROW_SIZE)
                        {
                            DoublePair world = worldCoordsOfScreen(atX, atY);
                            DoublePair field = playfield.electricFieldAt(world.x, world.y);
                            
                            double magnitude = Math.sqrt(field.x * field.x + field.y * field.y);
                            
                            if(magnitude >= 0.0000001)
                            {
                                double dirX = 0, dirY = 0;

                                dirX = field.x / magnitude;
                                dirY = field.y / magnitude;
                        
                                
                                int screenDeltaX = (int) (dirX * 5);
                                int screenDeltaY = (int) (-dirY * 5);
                        
                                // Select a color based on magnitude and draw vector
                                {   
                                    double brightnessRatio = magnitude / maxMagnitude;
                                    
                                    /*
                                    brightnessRatio = Math.min(brightnessRatio, 1.0);
                                    brightnessRatio = Math.max(brightnessRatio, 0.0);
                                    
                                    // System.out.println(brightnessRatio);
                                    
                                    if(brightnessRatio >= 1.0 / 65536)
                                    {
                                        double logizedBrightness;
                                        double topValue = (1.0 - brightnessRatio) * 
                                            Math.pow(2.0, 16.0);
                                             
                                        if(topValue <= 1.0)
                                            logizedBrightness = 1.0;
                                        else
                                            logizedBrightness = 1.0 - 
                                            (Math.log(topValue) / (Math.log(2.0) * 16.0));
                                
                                        logizedBrightness = Math.max(logizedBrightness, 0.0);
                                    
                                        if(logizedBrightness >= 1.0 / 255.0)
                                        {
                                            g.setColor(new Color(0, 
                                                (int) (255 * logizedBrightness), 0));
                                            
                                            drawArrow(g, atX - screenDeltaX, atY - screenDeltaY,
                                                atX + screenDeltaX, atY + screenDeltaY, 
                                                FIELD_ARROW_HEAD_SIZE);
                                        }
                                    } */ 
                                    
                                    brightnessRatio = Math.min(brightnessRatio, 1.0);
                                    brightnessRatio = Math.max(brightnessRatio, 0.0);
                                    
                                    brightnessRatio = Math.pow(brightnessRatio, 0.25);
                                    
                                    // System.out.println(brightnessRatio);
                                    
                                    if(brightnessRatio >= 1.0 / 255.0)
                                    {
                                        g.setColor(new Color(0, 
                                            (int) (255 * brightnessRatio), 0));
                                            
                                        drawArrow(g, atX - screenDeltaX, atY - screenDeltaY,
                                           atX + screenDeltaX, atY + screenDeltaY, 
                                           FIELD_ARROW_HEAD_SIZE);
                                        
                                    } 
                                }
                            }
                        }
                }
            }
            
            // Render particles
            {
                Vector particles = playfield.particles;
                
                IntPair centerPair = screenCoordsOfWorld(0, 0);
                int centerX = centerPair.x;
                int centerY = centerPair.y;
                
                FontMetrics fontMetrics = g.getFontMetrics();

                int fontAscent = fontMetrics.getAscent();
                int fontDescent = fontMetrics.getDescent();
                
                for(int i = 0; i < particles.size(); i++)
                {
                    Particle p = (Particle) particles.elementAt(i);
                    boolean firstTrace = true;
                    int particleSize, halfSize;
                    Color particleColor;

                    // Determine attributes about particle
                    {
                        // Color
                            if(p.charge == 0)
                                particleColor = Color.magenta;
                            else if(p.charge > 0)
                                particleColor = Color.green;
                            else 
                                particleColor = Color.red;
                    
                        // Particle size
                            if(p.mass < 1000)
                                particleSize = 5;
                            else if(p.mass < 2000)
                                particleSize = 7;
                            else
                                particleSize = 9; 

                            halfSize = (particleSize - 1) / 2;                    
                    }
                            
            
                    DynamicList listOfTraces = p.traces.list();
    
                    while(!listOfTraces.isEmpty())
                    {
                        Trace t = (Trace) listOfTraces.next();
                     
                        int canvasX, canvasY;
                           
                        // Get canvas coordinates of trace.
                            if(t.isDrawable)
                            {
                                canvasX = t.screenX;
                                canvasY = t.screenY;
                            }
                            else
                            {
                                IntPair pair = screenCoordsOfWorld(t.posX, t.posY);
                        
                                canvasX = pair.x;
                                canvasY = pair.y;
                                
                                t.screenX = canvasX;
                                t.screenY = canvasY;
                                
                                t.isDrawable = true;            
                            }   

                        // Draw trace
                            g.setColor(particleColor);                        
                        
                            if(firstTrace)
                            {
                                g.fillOval((int) (canvasX - halfSize), (int) (canvasY - halfSize), 
                                    particleSize, particleSize);
                            }
                            else {
                                g.fillOval((int) (canvasX - (halfSize - 1)), (int) (canvasY - 
                                    (halfSize - 1)), particleSize - 2, particleSize - 2);
                            }
                            
                        if(firstTrace)
                        {
                            if(p.isSelected)
                                g.drawRect((int) (canvasX - halfSize - 3), 
                                    (int) (canvasY - halfSize - 3),
                                    particleSize + 5, particleSize + 5);
        
                            if(p.isAnchored)
                            {
                                g.drawOval((int) (canvasX - halfSize - 2), 
                                    (int) (canvasY - halfSize - 2),
                                    particleSize + 3, particleSize + 3);
                            }
                            
                            if(!playfield.isSimulating || 
                                !playfield.controls.viewNoVectorsWhileSimulatingBox.getState())
                            {
                                renderVector(g, canvasX, canvasY, p.accX, p.accY,
                                    playfield.controls.viewAccelerationGroup.getSelected(),
                                        1.0, Color.green);
                                
                                renderVector(g, centerX, centerY, p.posX, p.posY, 
                                    playfield.controls.viewPositionGroup.getSelected(), 
                                        1.0, Color.lightGray);
                            
                                renderVector(g, canvasX, canvasY, p.forceX, p.forceY,
                                    playfield.controls.viewForceGroup.getSelected(),
                                        10.0, Color.yellow);
                                                   
                                renderVector(g, canvasX, canvasY, p.velX, p.velY,
                                    playfield.controls.viewVelocityGroup.getSelected(), 
                                        1.0, particleColor);
                            }
                            
                            if(!playfield.isSimulating ||
                                !playfield.controls.viewNoInfoWhileSimulatingBox.getState())
                            {
                                if(p.hasViewer || playfield.controls.viewShowLabelsBox.getState())
                                {
                                    g.setColor(Color.white);
                                    g.drawString(p.label, canvasX + halfSize * 2, 
                                        canvasY + halfSize + fontAscent);
                                }
                                
                                if(playfield.controls.viewShowVelocityBox.getState() &&
                                    (!playfield.isSimulating || 
                                    !playfield.controls.viewNoVectorsWhileSimulatingBox.
                                    getState()))
                                {
                                    IntPair pair = screenVectorOfWorldVector(p.velX, p.velY,
                                        playfield.controls.viewVelocityGroup.getSelected(),
                                        1.0);
                                    
                                    int destX = canvasX + pair.x;
                                    int destY = canvasY - pair.y;
                                        
                                    if(destX != canvasX || destY != canvasY)
                                    {
                                        String s;
                                    
                                        s = "(";
                                        
                                        if(p.velX == (double) ((int) p.velX))
                                            s += new Integer((int) p.velX).toString();
                                        else
                                            s += new Double(ExtDouble.truncatedOf(p.velX, 3)).
                                                toString();
                                                
                                        s += ",";
                                        
                                        if(p.velY == (double) ((int) p.velY))
                                            s += new Integer((int) p.velY).toString();
                                        else
                                            s += new Double(ExtDouble.truncatedOf(p.velY, 3)).
                                                toString();
                                        
                                        s += ")";
                                            
                                        g.setColor(Color.white);
                                    
                                        g.drawString(s, destX, destY);
                                    }
                                }
                                
                                if(playfield.controls.viewShowPositionBox.getState())
                                {
                                    String s;
                                    
                                    s = "(";
                                        
                                    if(p.posX == (double) ((int) p.posX))
                                        s += new Integer((int) p.posX).toString();
                                    else
                                        s += new Double(ExtDouble.truncatedOf(p.posX, 3)).
                                            toString();
                                            
                                    s += ",";
                                    
                                    if(p.posY == (double) ((int) p.posY))
                                        s += new Integer((int) p.posY).toString();
                                    else
                                        s += new Double(ExtDouble.truncatedOf(p.posY, 3)).
                                            toString();
                                    
                                    s += ")";
                                    
                                    g.setColor(Color.white);
                                    
                                    g.drawString(s, canvasX + 4 + halfSize * 2, 
                                        canvasY - halfSize - fontDescent);
                                
                                }
                                
                                if(playfield.controls.viewShowChargeBox.getState())
                                {
                                    String s;
                                    
                                    if(p.charge == (int) p.charge)
                                        s = new Integer((int) p.charge).toString();
                                    else
                                        s = new Double(p.charge).toString();
                                    
                                    if(p.charge >= 0)
                                        s = "+" + s;
                                        
                                    g.setColor(Color.white);
                                    
                                    g.drawString(s, canvasX - halfSize * 2 - 
                                        fontMetrics.stringWidth(s), canvasY - halfSize - 
                                        fontDescent);
                                }
                                
                                if(playfield.controls.viewShowMassBox.getState())
                                {
                                    String s;
                                    
                                    if(p.mass == (int) p.mass)
                                        s = new Integer((int) p.mass).toString();
                                    else
                                        s = new Double(p.mass).toString();
                                    
                                    g.setColor(Color.yellow);
                                                                    
                                    g.drawString(s, canvasX - halfSize * 2 - 
                                        fontMetrics.stringWidth(s), 
                                        canvasY + halfSize + fontAscent);
                                }
                            }
                        }
                        
                        firstTrace = false;
                    }
                }
            }
         
            // Dump rendering into active graphics
                activeGraphics.drawImage(backImage, 0, 0, this);      
                
            // Refresh viewed information about world
                refreshTicks.registerTick();
                // playfield.controls.actualRefreshRate = refreshTicks.tickRate();
        } 
    }
         
    void renderVector(Graphics g, int fromX, int fromY, double deltaX, double deltaY,
        String choiceText, double scaleFactor, Color color)
    
    {
        IntPair pair = screenVectorOfWorldVector(deltaX, deltaY, choiceText, scaleFactor);
                
        int destX = fromX + pair.x;
        int destY = fromY - pair.y;
     
        if(fromX != destX || fromY != destY)
        {
            g.setColor(color);   
            drawArrow(g, fromX, fromY, destX, destY);
        }
    }

    private IntPair screenVectorOfWorldVector(double deltaX, double deltaY, String choiceText, 
        double scaleFactor)
    {
        if(choiceText == "Off")
            return new IntPair(0, 0); 
        
        // Normalize vector if necessary
        {
            if(choiceText == "Unit")
            {
                double magnitude = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
                
                if(magnitude > 0.00000001)
                {
                    deltaX /= magnitude;
                    deltaY /= magnitude;
                }   
            }
            else
            {
                deltaX *= scaleFactor;
                deltaY *= scaleFactor;
            }
        }
                
        return new IntPair(screenDistanceOfWorldDistance(deltaX), 
            screenDistanceOfWorldDistance(deltaY));
    }
        
    void drawArrow(Graphics g, int fromX, int fromY,
        int toX, int toY)
    {
        drawArrow(g, fromX, fromY, toX, toY, screenDistanceOfWorldDistance(1.0 / 3.0));
    }
    
    void drawArrow(Graphics g, int fromX, int fromY, 
        int toX, int toY, int headLength)
    {
        double theta = Math.PI / 9.0;
        
        // Draw main line
            g.drawLine(fromX, fromY, toX, toY);
        
            Math2DVector dir = new Math2DVector(fromX - toX, fromY - toY).normalize();
                /* reversed direction here */
    
        // Draw left tip
            Math2DVector leftTip = dir.copy();
                
            leftTip.rotateBy(theta);
            leftTip.multiplyBy(headLength);
            leftTip.addOn(toX, toY);
        
            g.drawLine(toX, toY, (int) Math.round(leftTip.x), (int) Math.round(leftTip.y));
        
        // Draw right tip
            Math2DVector rightTip = dir.copy();
                
            rightTip.rotateBy(-theta);
            rightTip.multiplyBy(headLength);
            rightTip.addOn(toX, toY);
        
            g.drawLine(toX, toY, (int) Math.round(rightTip.x), (int) Math.round(rightTip.y));
    }
    
    public IntPair screenCoordsOfWorld(double worldX, double worldY)
    {
        int canvasX = (int) (((worldX - displacementX) * 
            playfield.controls.zoomControl.zoomFactor()) * 240 / 10) + canvasWidth / 2;
        int canvasY = (int) (-((worldY - displacementY) * 
            playfield.controls.zoomControl.zoomFactor()) * 240 / 10) + canvasHeight / 2;
                    
        return new IntPair(canvasX, canvasY);
    }

    public DoublePair worldCoordsOfScreen(double screenX, double screenY)
    {
        double posX = (screenX - canvasWidth / 2)  * (10.0 / (240.0 * 
            playfield.controls.zoomControl.zoomFactor())) + displacementX;
        double posY = (screenY - canvasHeight / 2) * (-10.0 / (240.0 * 
            playfield.controls.zoomControl.zoomFactor())) + displacementY;
                            
        return new DoublePair(posX, posY);
    }
    
    public int screenDistanceOfWorldDistance(double distance)
    {
        return (int) (distance * 24 * playfield.controls.zoomControl.zoomFactor()); 
    }
    
    public double worldDistanceOfScreenDistance(int distance)
    {
        return distance / (24.0 * playfield.controls.zoomControl.zoomFactor());
    }
}





