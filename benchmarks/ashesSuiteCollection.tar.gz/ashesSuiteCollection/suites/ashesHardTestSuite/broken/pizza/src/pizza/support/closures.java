package pizza.support;

public class ExceptionWrapper extends RuntimeException {

    public Throwable thrown;

    public ExceptionWrapper(Throwable thrown) {
	this.thrown = thrown;
    }
}

public class UndeclaredException extends Error {}

public class Closure {
    public Object $apply() { throw new InternalError(); }

    public Object $apply(Object x1) { throw new InternalError(); }

    public Object $apply(Object x1, Object x2) { throw new InternalError(); }

    public Object $apply(Object x1, Object x2, Object x3) { throw new InternalError(); }

    public Object $apply(Object x1, Object x2, Object x3, Object x4) { throw new InternalError(); }

    public Object $apply(Object x1, Object x2, Object x3, Object x4, Object x5) { throw new InternalError(); } 

    public Object $apply(Object x1, Object x2, Object x3, Object x4, Object x5, 
			  Object x6) { throw new InternalError(); } 

    public Object $apply(Object x1, Object x2, Object x3, Object x4, Object x5, 
			  Object x6, Object x7) { throw new InternalError(); } 

    public Object $apply(Object x1, Object x2, Object x3, Object x4, Object x5, 
			  Object x6, Object x7, Object x8) { throw new InternalError(); } 

    public Object $apply(Object x1, Object x2, Object x3, Object x4, Object x5, 
			  Object x6, Object x7, Object x8, Object x9) { throw new InternalError(); }

    public Object $apply(Object x1, Object x2, Object x3, Object x4, Object x5, 
			  Object x6, Object x7, Object x8, Object x9, Object x10) { throw new InternalError(); }
}



/*

  closure code (for closures that throw exceptions)

  Object foo(Object arg1, ..., Object argn) {
    try {
      <body>
    } catch (DeclaredException_1 e) {
      throw new ExceptionWrapper(e);
    } catch (DeclaredException_n e) {
      throw new ExceptionWrapper(e);
    }
  }

  application:

  call_closure1(closure, arg1, ..., argn) {
    try {
      return closure.apply(arg1, ..., argn) {


  }

  seq {
    try {
      return <closure>.apply(arg1, ..., argn);
    } catch (ExceptionWrapper e) {
      if (e instanceof DeclaredException1) {
        throw (DeclaredException1)e
      } else if (e instanceof DeclaredException2) {
        throw (DeclaredException2)e
      } else {
        throw new UndeclaredException();
      }
    }
  }

*/



