package pizza.support;

abstract public class array {

    public abstract int length();
    public abstract Object at(int i);
    public abstract void at(int i, Object x);

    public boolean[] booleanElems() { throw new InternalError(); }
    public byte[] byteElems()       { throw new InternalError(); }
    public short[] shortElems()     { throw new InternalError(); }
    public char[] charElems()       { throw new InternalError(); }
    public int[] intElems()         { throw new InternalError(); }
    public long[] longElems()       { throw new InternalError(); }
    public float[] floatElems()     { throw new InternalError(); }
    public double[] doubleElems()   { throw new InternalError(); }
    public Object[] ObjectElems()   { throw new InternalError(); }

    public static Object asObject(Object x) {
	return x;
    }

    public abstract Object toObject();

    public static array fromObject(Object a) {
	if (a instanceof boolean[]) 
	    return new booleanArray((boolean[]) a);
	else if (a instanceof byte[]) 
	    return new byteArray((byte[]) a);
	else if (a instanceof short[]) 
	    return new shortArray((short[]) a);
	else if (a instanceof char[]) 
	    return new charArray((char[]) a);
	else if (a instanceof int[]) 
	    return new intArray((int[]) a);
	else if (a instanceof long[]) 
	    return new longArray((long[]) a);
	else if (a instanceof float[]) 
	    return new floatArray((float[]) a);
	else if (a instanceof double[]) 
	    return new doubleArray((double[]) a);
	else if (a instanceof array)
	    return (array)a;
	else
	    return new ObjectArray((Object[]) a);
    }
}

public class ObjectArray extends array {

    public Object[] elems;

    public ObjectArray(Object[] elems) {
	this.elems = elems;
    }

    public static ObjectArray make(Object[] elems) {
	if (elems == null) return null;
	else return new ObjectArray(elems);
    }
	
    public int length() {
	return this.elems.length;
    }

    public Object at(int i) {
	return this.elems[i];
    }
	
    public void at(int i, Object x) {
	this.elems[i] = x;
    }

    public Object toObject() {
	return this.elems;
    }

    public Object[] ObjectElems() {
	return this.elems;
    }
}

public class booleanArray extends array {

    public boolean[] elems;

    public booleanArray(boolean[] elems) {
	this.elems = elems;
    }
	
    public static booleanArray make(boolean[] elems) {
	if (elems == null) return null;
	else return new booleanArray(elems);
    }

    public int length() {
	return this.elems.length;
    }

    public Object at(int i) {
	return new Boolean(this.elems[i]);
    }
	
    public void at(int i, Object x) {
	this.elems[i] = ((Boolean)x).booleanValue();
    }

    public Object toObject() {
	return this.elems;
    }

    public boolean[] booleanElems() {
	return this.elems;
    }
}

public class byteArray extends array {

    public byte[] elems;

    public byteArray(byte[] elems) {
	this.elems = elems;
    }
	
    public static byteArray make(byte[] elems) {
	if (elems == null) return null;
	else return new byteArray(elems);
    }

    public int length() {
	return this.elems.length;
    }

    public Object at(int i) {
	return new Integer(this.elems[i]);
    }
	
    public void at(int i, Object x) {
	this.elems[i] = ((Number)x).byteValue();
    }

    public Object toObject() {
	return this.elems;
    }

    public byte[] byteElems() {
	return this.elems;
    }
}

public class shortArray extends array {

    public short[] elems;

    public shortArray(short[] elems) {
	this.elems = elems;
    }

    public static shortArray make(short[] elems) {
	if (elems == null) return null;
	else return new shortArray(elems);
    }
	
    public int length() {
	return this.elems.length;
    }

    public Object at(int i) {
	return new Integer(this.elems[i]);
    }
	
    public void at(int i, Object x) {
	this.elems[i] = ((Number)x).shortValue();
    }

    public Object toObject() {
	return this.elems;
    }

    public short[] shortElems() {
	return this.elems;
    }
}

public class charArray extends array {

    public char[] elems;

    public charArray(char[] elems) {
	this.elems = elems;
    }

    public static charArray make(char[] elems) {
	if (elems == null) return null;
	else return new charArray(elems);
    }
	
    public int length() {
	return this.elems.length;
    }

    public Object at(int i) {
	return new Integer(this.elems[i]);
    }
	
    public void at(int i, Object x) {
	this.elems[i] = (char)((Number)x).intValue();
    }

    public Object toObject() {
	return this.elems;
    }

    public char[] charElems() {
	return this.elems;
    }
}

public class intArray extends array {

    public int[] elems;

    public intArray(int[] elems) {
	this.elems = elems;
    }

    public static intArray make(int[] elems) {
	if (elems == null) return null;
	else return new intArray(elems);
    }
	
    public int length() {
	return this.elems.length;
    }

    public Object at(int i) {
	return new Integer(this.elems[i]);
    }
	
    public void at(int i, Object x) {
	this.elems[i] = ((Number)x).intValue();
    }

    public Object toObject() {
	return this.elems;
    }

    public int[] intElems() {
	return this.elems;
    }
}

public class longArray extends array {

    public long[] elems;

    public longArray(long[] elems) {
	this.elems = elems;
    }

    public static longArray make(long[] elems) {
	if (elems == null) return null;
	else return new longArray(elems);
    }
	
    public int length() {
	return this.elems.length;
    }

    public Object at(int i) {
	return new Long(this.elems[i]);
    }
	
    public void at(int i, Object x) {
	this.elems[i] = ((Number)x).longValue();
    }

    public Object toObject() {
	return this.elems;
    }

    public long[] longElems() {
	return this.elems;
    }
}

public class floatArray extends array {

    public float[] elems;

    public floatArray(float[] elems) {
	this.elems = elems;
    }

    public static floatArray make(float[] elems) {
	if (elems == null) return null;
	else return new floatArray(elems);
    }
	
    public int length() {
	return this.elems.length;
    }

    public Object at(int i) {
	return new Float(this.elems[i]);
    }
	
    public void at(int i, Object x) {
	this.elems[i] = ((Number)x).floatValue();
    }

    public Object toObject() {
	return this.elems;
    }

    public float[] floatElems() {
	return this.elems;
    }
}

public class doubleArray extends array {

    public double[] elems;

    public doubleArray(double[] elems) {
	this.elems = elems;
    }

    public static doubleArray make(double[] elems) {
	if (elems == null) return null;
	else return new doubleArray(elems);
    }
	
    public int length() {
	return this.elems.length;
    }

    public Object at(int i) {
	return new Double(this.elems[i]);
    }
	
    public void at(int i, Object x) {
	this.elems[i] = ((Number)x).doubleValue();
    }

    public Object toObject() {
	return this.elems;
    }

    public double[] doubleElems() {
	return this.elems;
    }
}
