package pizza.support;

public class InternalError extends Error {}
