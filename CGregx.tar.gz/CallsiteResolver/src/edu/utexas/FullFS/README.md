Java version for N Heintze's paper in 2001. Rules are adopted from Manu's paper.
