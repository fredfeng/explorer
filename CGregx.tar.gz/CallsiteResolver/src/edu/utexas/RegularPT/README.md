Manu's paper in OOPSLA2005, available in Soot.
